var chatHandler = (function() {
	var FADE_TIME = 150;
	// ms
	var TYPING_TIMER_LENGTH = 400;
	// ms
	var COLORS = ['#e21400', '#91580f', '#f8a700', '#f78b00', '#58dc00', '#287b00', '#a8f07a', '#4ae8c4', '#3b88eb', '#3824aa', '#a700ff', '#d300e7'];
	var userinfo = {};
	var connected = false;
	var username = '';
	var numUsers = 0;
	var typing = false;
	var lastTypingTime;
	var userColor = {};

	var scroller = A.Scroll('#chat_article');

	var updateTyping = function() {
		if (connected) {

			if (!typing) {
				typing = true;

				socket.emit('typing');
			}
			lastTypingTime = (new Date()).getTime();

			setTimeout(function() {
				var typingTimer = (new Date()).getTime();
				var timeDiff = typingTimer - lastTypingTime;
				if (timeDiff >= TYPING_TIMER_LENGTH && typing) {
					socket.emit('stop typing');
					typing = false;
				}
			}, TYPING_TIMER_LENGTH);
		}
	};

	$('#chat_btn_send').click(function() {
		var msg = $('#chat_msg');
		if (!msg.val()) {
			A.showToast('请输入消息哦');
			return;
		}
		socket.emit('new message', {
			message : msg.val()
		});
		addMsg({
			message : msg.val(),
			userinfo : userinfo
		});
		msg.val('');
	});

	$('#chat_msg').on('input', function() {
		updateTyping();
	});

	var addMsg = function(data) {
		var className = data.className ? data.className : 'chat';
		var un = data.userinfo.username || '扫地僧';
		userColor[un] = userColor[un] ? userColor[un] : getCls();
		$('#chat_template').renderAfter({
			username : un,
			uid : data.userinfo.uid,
			msg : data.message,
			cls : userColor[un],
			type : data.type || '',
			lou : username == un ? 'lou' : ''
		}, function() {
			scroller.refresh();
			if (scroller.pagesY.length > 1)
				scroller.scrollToPage(scroller.pagesY.length - 1, 500);
		});

	};

	var getCls = function() {
		var n = Math.floor(Math.random() * 10);
		return n < 6 ? n : getCls();
	};

	var getRandomColor = function() {
		return '#' + (function(color) {
			return (color += '0123456789abcdef'[Math.floor(Math.random() * 16)]) && (color.length == 6) ? color : arguments.callee(color);
		})('');
	};

	var socket;
	//var socket = io.connect('http://192.168.10.204:8001',{path:'/process/notify/webchat/handle?'});//io('http://192.168.10.204:8001/process/notify/webchat');

	var _init = function(cb) {
		if (socket)
			return;

		socket = io('http://www.exmobi.cn:3000');

		setTimeout(function() {
			cb && cb(connected);
		}, 3000);

		socket.on('connect', function(data) {
			connected = true;
			cb && cb(connected);
			cb = null;
		});

		socket.on("error", function(error) {
			connected = false;
			cb && cb(connected);
			cb = null;
		});
		// Whenever the server emits 'login', log the login message
		socket.on('login', function(data) {
			username = data.userinfo.username;
			addMsg({
				message : '终于进入传说中的猿媛聊天室，好开心！',
				userinfo : userinfo
			});
			addMsg({
				message : '话说我是第' + data.numUsers + '位码农，请多关照！！',
				userinfo : userinfo
			});
			numUsers = data.numUsers;
		});

		// Whenever the server emits 'new message', update the chat body
		socket.on('new message', function(data) {
			data.message = data.message;
			addMsg(data);
		});

		// Whenever the server emits 'user joined', log it in the chat body
		socket.on('user joined', function(data) {
			addMsg({
				message : '有新伙伴' + data.userinfo.username + '加入！',
				userinfo : data.userinfo
			});
			numUsers = data.numUsers;
		});

		// Whenever the server emits 'user left', log it in the chat body
		socket.on('user left', function(data) {
			addMsg({
				message : '小伙伴' + data.userinfo.username + '已经离开！',
				userinfo : data.userinfo
			});
			numUsers = data.numUsers;
			addMsg({
				message : '剩余' + data.numUsers + '位小伙伴！'
			});
		});

		// Whenever the server emits 'typing', show the typing message
		socket.on('typing', function(data) {
			data.message = data.userinfo.username + '正在输入。。。';
			data.type = 'typing';
			addMsg(data);
		});

		// Whenever the server emits 'stop typing', kill the typing message
		socket.on('stop typing', function(data) {
			$('.' + data.userinfo.username + '.typing').remove();
		});

	};

	var _isConnection = function() {
		return connected;
	};
	//socket.emit('add user', username);
	var _addUser = function(o) {
		userinfo = o;
		socket.emit('add user', userinfo);
	};

	return {
		init : _init,
		isConnection : _isConnection,
		addUser : _addUser
	};
})();

