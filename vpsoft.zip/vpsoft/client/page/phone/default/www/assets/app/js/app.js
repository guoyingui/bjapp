﻿var $config = {
	bbs : 'http://discuz.exmobi.cn',
	qianming : '[此消息来自Weixin-Agile Lite版论坛]',
	exmobiSevice : '/process/service/ednlite'
};

function setCookie(c_name, value, expiredays) {
	var date = new Date();
	date.setTime(date.getTime() - 10000);
	document.cookie = c_name+"=828; expires=" + date.toGMTString();

	var exdate = new Date();
	exdate.setDate(exdate.getDate() + expiredays);
	document.cookie = c_name + "=" + escape(value) + ((expiredays == null) ? "" : ";expires=" + exdate.toGMTString());
}

function getCookie(c_name) {
	if (document.cookie.length > 0) {
		c_start = document.cookie.indexOf(c_name + "=");
		if (c_start != -1) {
			c_start = c_start + c_name.length + 1;
			c_end = document.cookie.indexOf(";", c_start);
			if (c_end == -1)
				c_end = document.cookie.length;
			return unescape(document.cookie.substring(c_start, c_end));
		}
	}
	return "";
}

var $native = function() {
	var _session = null;

	var _session = function() {
		if (!_session)
			_session = {};
		if (arguments.length == 1) {
			try {
				return A.JSON.parse(_session[arguments[0]]);
			} catch(e) {
				return _session[arguments[0]];
			}

		} else if (arguments.length == 2) {
			var v = arguments[1] || '';
			try {
				_session[arguments[0]] = A.JSON.stringify(v);
				return _session[arguments[0]];
			} catch(e) {
				_session[arguments[0]] = v;
				return _session[arguments[0]];
			}

		} else {
			return null;
		}

	};
	var _cache = function() {
		var k,
		    v;
		k = arguments[0];
		if (arguments.length == 2) {
			v = arguments[1] || '';
			try {
				localStorage[k]=A.JSON.stringify(v);
				//return true;
			} catch(e) {
				if(typeof v=='string') localStorage[k]=v.toString();
				//return false;
			}
		} else {
			try {
				return A.JSON.parse(localStorage[k]);
			} catch(e) {
				return localStorage[k];
			}
		}
	};

	return {
		session : _session,
		cache : _cache
	};
}();

var $util = function($) {

	var _ajax = function(opt) {
		A.ajax(opt);
	};

	return {
		ajax : _ajax
	};
}(A.$);

//启动agile
/*
 var $config = {
 exmobiSevice : '${$native.getAppSetting().domain}/process/service/${ClientUtil.getAppId()}'
 };
 */
A.launch({
	readyEvent : '', //触发ready的事件，在ExMobi中为plusready
	backEvent : 'backmonitor', //宿主容器的返回按钮事件
	crossDomainHandler : null,//跨域请求的处理类，一般用于提供了网络请求类的宿主容器中，一般浏览器中不需要设置
	showPageLoading : true,//section页面加载是否显示进度条
	viewSuffix : '.html',//加载静态文件的默认后缀
	lazyloadPlaceholder : '',//懒人加载的默认图片
	usePageParam : false,//单页模式是否记录section页面访问参数，此参数通过base64编码记录，会比较长；多页模式建议设置为false
	pageParamEncode : false,//是否对hash记录的参数信息进行编码
	autoInitCom : true,//是否默认初始化组件，默认为true初始化，可以设置为false不初始化，目前初始化的操作有数据注入和popup打开时
	iScrollOptions : {},//设置IScroll默认配置项
	mode : 'single',//页面模式，默认是单页模式，可选值single（单页）/muti（多页），多页的时候url无hash
	crossDomainHandler : function(opts) {
		$util.ajax(opts);
	}
	//agileReadyEvent : '',//AL正确启动后触发的事件名称
});
/*
 $(document).on(A.options.clickEvent, '#ratchet_form_article span', function(){
 A.alert('提示', $(this).attr('class').replace(/.* /,''));
 return false;
 });
 */

var messageHandler = (function() {
	var _addQianming = function(msg) {
		return (msg || '') + $config.qianming;
	};

	return {
		addQianming : _addQianming
	};
})();
var favoritHandler = (function() {
	var myFavorit;

	var _get = function() {
		_init('multi');
		return myFavorit;
	};

	var _set = function(obj) {
		_init();
		if (myFavorit.list[obj.id]) {
			_del(obj.id);
			$native.cache("myFavorit", myFavorit);
			return 1;
			//取消
		} else {
			if (myFavorit.count > 30) {
				for (var k in myFavorit.list) {
					_del(obj.id);
					break;
				}
			}
			myFavorit.count = myFavorit.count + 1;
			myFavorit.list[obj.id] = obj;
			$native.cache("myFavorit", myFavorit);
			return 2;
			//关注
		}
	};

	var _isHave = function(id) {
		_init();
		return myFavorit.list[id] ? true : false;
	};

	var _del = function(id) {
		_init();
		var arr = typeof id == 'string' ? [id] : id;
		for (var i = 0; i < arr.length; i++) {
			var id = arr[i];
			if (myFavorit.list[id])
				myFavorit.count = myFavorit.count - 1;
			delete myFavorit.list[id];
		}
	};

	var _init = function(type) {
		if (type == 'multi' || !myFavorit)
			myFavorit = $native.cache("myFavorit") || {
				count : 0,
				list : {}
			};
	};

	return {
		get : _get,
		set : _set,
		isHave : _isHave,
		init : _init,
		del : _del
	};

})();

var appHandler = (function() {
	var appManager = null;

	var _init = function(opts) {
		appManager = appManager || (new AppManager());
	};

	var _get = function(cb) {
		_init();
		appManager.isGetAppsShowProgress = false;
		appManager.onGetAppsCallback = function() {
			if (!appManager.isGetAppsSuccess()) {
				cb && cb([]);
				return;
			}
			var serverArr = appManager.applicationInfos;
			for (var i = 0; i < serverArr.length; i++) {
				serverArr[i].iconMain = $native.getRealPath(serverArr[i].iconMain);
				serverArr[i].iconLogo = $native.getRealPath(serverArr[i].iconLogo);
				serverArr[i].iconSelectedLogo = $native.getRealPath(serverArr[i].iconSelectedLogo);
			}

			cb && cb(serverArr);
		};
		appManager.startGetApps();
	};

	var _setup = function(id, cb) {
		_init();
		appManager.isSetupAppShowProgress = true;
		appManager.onSetupAppCallback = function() {
			cb && cb({
				result : appManager.isSetupAppSuccess() ? 'success' : 'fail'
			});
		};
		appManager.startSetupApp(id);
	};

	var _remove = function(id, cb) {
		_init();
		appManager.isRemoveAppShowProgress = true;
		appManager.onRemoveAppCallback = function() {
			cb && cb({
				result : appManager.isRemoveAppSuccess() ? 'success' : 'fail'
			});
		};
		appManager.startRemoveApp(id);
	};

	return {
		get : _get,
		setup : _setup,
		remove : _remove
	};

})();

