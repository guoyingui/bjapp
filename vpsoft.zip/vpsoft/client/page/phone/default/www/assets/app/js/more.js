// JavaScript Document
require(['jquery', 'jqm', 'agile'], function ($, jqm, agile) {
	var RequestParam = 0;
	$('.sech_icn2').on('touchstart click', function (e) {
		var opts = {
			id: 'tips_pbox', //[可选]弹出窗的id，相同的弹出窗将不会重复初始化
			html: '<div class="tips_pbox">' +
				'<span class="tipsb_icn"></span>' +
				'<ul class="tips_list">' +
				'<li class="tip_on">所有</li>' +
				'<li>已超时</li>' +
				'<li>即将超时</li>' +
				'<li>查询结果</li>' +
				'</ul></div>', //位于pop中的内容
			pos: null, //[可选]pop显示的位置和样式,top|bottom|center|left|right|custom
			css: {
				position: 'absolute',
				top: '82px',
				right: '15px',
				width: '102px',
				background: 'none'
			}, //[可选]自定义的样式
			isBlock: false //[可选]是否禁止关闭，false为不禁止，true为禁止，默认为false
		};
		var $popup = A.popup(opts);
		$popup.popup.find('.tips_list li').on('touchstart', function () {
			$popup.close();
		});
		return false;
	});
	//当refresh初始化会进入此监听
	$('#slider_article').on('refreshInit', function () {
		var refresh = A.Refresh('#slider_article');
		//监听下拉刷新事件，可以做一些逻辑操作，当data-scroll="pullup"时无效
		refresh.on('pulldown', function () {
			// setTimeout(function() {
			console.log('12321')
			$.ajax({
				url: '/project/second/sjxt/jspforapp/wokFlowHandle1.jsp',
				type: 'POST',
				dataType: 'json',
				success: function (data) {
					$(".pend_list ul").empty();
					var data = data.listData;
					for (var index = 0; index < data.length; index++) {
						var element = data[index];
						$('.pend_list ul').append(
							'<a href="Toreview.html"><li><div class="pend_mide">' +
							'<figure class="pd_icnl"></figure>' +
							'<hgroup><h4>' +
							element.flowname + '</h4>' +
							'<p id="hgroup">' + element.objectname + '<p>' +
							'<p><time>' + element.startdate + '</time>' + element.stepname + '</p></hgroup>' +
							'<div class="pend_bnt"><i class="pdb_icn1"></i><em></em></div></div>' +
							'</li></a>'
						)
					}
				}
			})
			// }, 1000);
			refresh.refresh(); //当scroll区域有dom结构变化需刷新
		});
		//监听上拉刷新事件，可以做一些逻辑操作，当data-scroll="pulldown"时无效
		refresh.on('pullup', function () {
			$.ajax({
				url: '/project/second/sjxt/jspforapp/wokFlowHandle1.jsp',
				type: 'POST',
				dataType: 'json',
				success: function (data) {
					var data = data.listData;
					RequestParam = RequestParam + 1;
					console.log(RequestParam);
					for (var index = 0; index < data.length; index++) {
						var element = data[index];
						$('.pend_list ul').append(
							'<a href="Toreview.html"><li><div class="pend_mide">' +
							'<figure class="pd_icnl"></figure>' +
							'<hgroup><h4>' +
							element.flowname + '</h4>' +
							'<p id="hgroup">' + element.objectname + '<p>' +
							'<p><time>' + element.startdate + '</time>' + element.stepname + '</p></hgroup>' +
							'<div class="pend_bnt"><i class="pdb_icn1"></i><em></em></div></div>' +
							'</li></a>'
						)
					}
				}
			})
			refresh.refresh(); //当scroll区域有dom结构变化需刷新
		});
	});

	var expansion = null;
	var container = $('.pend_list>ul > li > a');
	// console.log(container)
	for (var i = 0; i < container.length; i++) {
		var x,y,X,Y,swipeX,swipeY;
		// debugger;
		container[i].addEventListener('touchstart',function(event){
			x = event.changedTouches[0].pageX;
			y = event.changedTouches[0].pageY;
			swipeX = true;
			swipeY = true ;
			if(expansion){   //判断是否展开，如果展开则收起
				expansion.className = "";
			}    
		});
		container[i].addEventListener('touchmove', function(event){
			
			X = event.changedTouches[0].pageX;
			Y = event.changedTouches[0].pageY;        
			// 左右滑动
			if(swipeX && Math.abs(X - x) - Math.abs(Y - y) > 0){
				// 阻止事件冒泡
				event.stopPropagation();
				if(X - x > 10){   //右滑
					event.preventDefault();
					this.className = "";    //右滑收起
				}
				if(x - X > 10){   //左滑
					event.preventDefault();
					this.className = "swipeleft";   //左滑展开
					expansion = this;
				}
				swipeY = false;
			}
			// 上下滑动
			if(swipeY && Math.abs(X - x) - Math.abs(Y - y) < 0) {
				swipeX = false;
			}        
		});
		
	}

	// $(".hicn").on('touchstart click', function (e) {
	// 	e.preventDefault();
	// 	window.history.go(-1);
	// });

	// $(".pend_mide").on("swipeleft", function (e) {
	// 	// debugger;
	// 	e.preventDefault();
	// 	var nc = $(this).next().children().length,
	// 		ncw = $(this).next().children().width(),
	// 		w = $(this).parent().width() - 50 + 'px';
	// 	$(this).animate({
	// 		left: '-' + nc * ncw + 'px',
	// 		width: w
	// 	}, 500, 'linear');
	// 	$(this).parent().siblings().children().animate({
	// 		left: 0,
	// 		width: w
	// 	}, 500, 'linear');
	// });
	// $(".pend_mide").on("swiperight", function (e) {
	// 	e.preventDefault();
	// 	var w = $(this).parent().width();
	// 	$(this).animate({
	// 		left: 0,
	// 		width: w
	// 	}, 500, 'linear');
	// });

	$(".pd_btn").on('touchstart click', function () {
		var vthis = $(this),
			dvl = vthis.text();
		if (vthis.text() == "拒绝" || vthis.text() == "有条件通过" || vthis.text() == "不通过") {
			var opts = {
				id: 'tips_pbox2', //[可选]弹出窗的id，相同的弹出窗将不会重复初始化
				html: '<div class="pup_box" style="display:;">' +
					'<div class="pslt_part3">' +
					'<div class="pup_cap pup_cap2">' +
					'<h3>评审意见</h3></div>' +
					'<div class="pslt_are">' +
					'<textarea id="" class="mtip_txt mtip_txt2" placeholder=""></textarea>' +
					'<span class="par_nt">(<em>0</em>/250)</span></div>' +
					' <div class="pslt_bnt3 pslt_bnt4">' +
					'<a href="" class="ps_btn ps_btn8">确定<i class="pslt_l"></i></a><a href="" class="ps_btn ps_btn7">取消</a>' +
					'</div></div></div>', //位于pop中的内容
				pos: 'center', //[可选]pop显示的位置和样式,top|bottom|center|left|right|custom
				css: {}, //[可选]自定义的样式
				isBlock: false //[可选]是否禁止关闭，false为不禁止，true为禁止，默认为false
			};

			var $popup = A.popup(opts);
			$popup.popup.find('.ps_btn').on('touchstart', function () {
				$popup.close();
			});
		}
		/*vthis.parents("li").animate({
				opacity:0,
				display:'none'
				},200,'linear');
		setTimeout(function(){
			vthis.parents("li").remove();
		},200);*/
		return false;
	});


	$('.htxt').on('touchstart click', function (e) {
		var opts = {
			id: 'tips_pbox3', //[可选]弹出窗的id，相同的弹出窗将不会重复初始化
			html: '<div class="pup_box" style="">' +
				'<div class="pup_cap">' +
				'<input type="text" name="" value="" class="sech_ipt" id="" />' +
				'<i class="sech_icn sech_icn3"></i></div>' +
				'<div class="pslt_part">' +
				'<ul class="pslt_list">' +
				'<li class="pls_in">' +
				'<span class="pls_snp">&nbsp;</span><span class="pls_snp2">选择用户</span><span class="pls_snp3">编号</span>' +
				'</li><li>' +
				'<span class="pls_snp"><i class="pls_icn"></i></span><span class="pls_snp2">刘佳文</span><span class="pls_snp3">000321</span>' +
				'</li></ul>' +
				'<div class="pslt_bnt2">' +
				'<a href="" class="ps_btn ps_btn5">取消</a><a href="" class="ps_btn ps_btn6">确定</a>' +
				' </div></div></div>', //位于pop中的内容
			pos: 'center', //[可选]pop显示的位置和样式,top|bottom|center|left|right|custom
			css: {}, //[可选]自定义的样式
			isBlock: false //[可选]是否禁止关闭，false为不禁止，true为禁止，默认为false
		};
		var $popup = A.popup(opts);
		$popup.popup.find('.ps_btn').on('touchstart', function () {
			$popup.close();
		});
		return false;
	});

	$('.pat_btn').on('touchstart click', function (e) {
		var opts = {
			id: 'tips_pbox4', //[可选]弹出窗的id，相同的弹出窗将不会重复初始化
			html: '<div class="pup_box" style="">' +
				'<div class="pslt_mtxt">' +
				'<h4><i class="pls_icn3"></i></h4>' +
				'<p>提交评审后不能修改</p></div>' +
				'<div class="pslt_bnt3">' +
				'<a href="" class="ps_btn ps_btn8">确定<i class="pslt_l"></i></a><a href="" class="ps_btn ps_btn7">取消</a>' +
				' </div></div></div>', //位于pop中的内容
			pos: 'center', //[可选]pop显示的位置和样式,top|bottom|center|left|right|custom
			css: {}, //[可选]自定义的样式
			isBlock: false //[可选]是否禁止关闭，false为不禁止，true为禁止，默认为false
		};
		var $popup = A.popup(opts);
		$popup.popup.find('.ps_btn').on('touchstart', function () {
			$popup.close();
		});
		return false;
	});

	$('.cap_ad').on('touchstart click', function (e) {
		var opts = {
			id: 'tips_pbox5', //[可选]弹出窗的id，相同的弹出窗将不会重复初始化
			html: '<div class="pup_box" style="">' +
				'<div class="pslt_part4">' +
				'<div class="pslt_mtip pslt_mtip2"><figure>' +
				'<a href="" class="mtip_inc"><i class="mtip_icn"></i></a>' +
				'<em>类别</em><span class="mtip_cos">' +
				'<select name="" class="mtip_sel" id="mtip_sel"><option value="">一般</option></select>' +
				'</span></figure></div>' +


				'<div class="pslt_mtip pslt_mtip2"><figure>' +
				'<a href="" class="mtip_inc"><i class="mtip_icn"></i></a>' +
				'<em>严重程度</em><span class="mtip_cos">' +
				'<select name="" class="mtip_sel" id="mtip_sel"><option value="">一般</option></select>' +
				'</span></figure></div>' +


				'<div class="pslt_mtip pslt_mtip2"><figure>' +
				'<a href="" class="mtip_inc"><i class="mtip_icn"></i></a>' +
				'<em>关联附件</em><span class="mtip_cos">' +
				'<select name="" class="mtip_sel" id="mtip_sel"><option value="">一般</option></select>' +
				'</span></figure></div>' +
				'<div class="pslt_mtip pslt_mtip3">' +
				'<figure><em>位置</em><span class="mtip_spnt">' +
				'<input type="text" name="" value="" placeholder="填写描述" id="" class="info_txt" disabled="" /></span><figure></div>' +
				'<div class="pslt_mtip pslt_mtip4"><figure><em>描述:</em></figure>' +
				'<hgroup><textarea id="" class="mtip_txt"></textarea></hgroup></div>' +
				'<div class="pslt_bnt2">' +
				'<a href="" class="ps_btn ps_btn5">取消</a><a href="" class="ps_btn ps_btn6">确定</a>' +
				'</div></div></div>', //位于pop中的内容
			pos: 'center', //[可选]pop显示的位置和样式,top|bottom|center|left|right|custom
			css: {}, //[可选]自定义的样式
			isBlock: false //[可选]是否禁止关闭，false为不禁止，true为禁止，默认为false
		};
		var $popup = A.popup(opts);
		$popup.popup.find('.ps_btn').on('touchstart', function () {
			$popup.close();
		});
		return false;
	});
});