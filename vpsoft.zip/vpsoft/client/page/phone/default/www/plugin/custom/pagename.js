/*
*	ExMobi4.x+ JS
*	Version	: 1.0.0
*	Author	: luoyi
*	Email	: 
*	Weibo	: 
*	Copyright 2016 (c) 
*/

		var flowid, flowexpid, stepid, stepexpid, objectID;
		var objecttype, formtype, formid, fid, steptype, stepcode;
		var userid, username;
		stepcode = user.stepcode;
		var nowDate = new Date();
		var sysdate = nowDate.getFullYear() + "-" + (nowDate.getMonth() + 1) + "-" + nowDate.getDate();
		var nextstepid = "";
		var nextstepidh = "";
		var nextstepid2 = "";
		var nextstepid3 = "";
		var ycbzbh = "";
		var stepUserSelect;
		//查询输入计数
        var jsparam=0;
		
		//左滑右滑
        $("body").on("touchstart", function(e) {
            e.preventDefault();
            startX = e.originalEvent.changedTouches[0].pageX,
            startY = e.originalEvent.changedTouches[0].pageY;
        });
        $("body").on("touchmove", function(e) {
            e.preventDefault(); 
            moveEndX = e.originalEvent.changedTouches[0].pageX,
            moveEndY = e.originalEvent.changedTouches[0].pageY,
            X = moveEndX - startX,
            Y = moveEndY - startY;
            //从左向右滑
            if ( Math.abs(X) > Math.abs(Y) && X < -35 ) {
                tabs[1].onclick();
            }else if ( Math.abs(X) > Math.abs(Y) && X > 35 ) {//从右向左滑
                tabs[0].onclick();
            }
        });
		$(function(){
			layer.open({
            	type: 2
        	});
        	if(user){
        		if (user.steptype == 8) { //处理步骤
                    $("#tjButton").show();
                    $("#spButton").hide();
                } else if (user.steptype == 4) { //审批步骤
                    $("#tjButton").hide();
                    $("#spButton").show();
                }
                hideField();
        	}
        });
		//加载完毕后触发plusready事件
        document.addEventListener("plusready",function(){
            //这里可以调用ExMobi提供的jsapi
            //请求流程数据
            try {
                getInfomation(user);
            } catch (e) {

            }
        },false);
        function hideField(){
        	var objecttype = user.objecttype;
        	var stepcode = user.stepcode;
        	//项目申请
        	
        	if(objecttype==2590){
        		if(stepcode=="02"){
        			$("#m_wcshjsx").parent().parent().hide();
        			$("#m_sffhywry").parent().parent().hide();
        			$("#m_xmjlclyj").parent().hide();
        		}else if(stepcode=="03"){
        			$("#m_sfddzyxqsl").parent().parent().hide();
        			$("#m_ddksxqsl").parent().hide();
        			$("#m_ddjsxqsl").parent().hide();
        		}else{
        			$("#m_sffhywry").attr("disabled",true);
        			$("#m_wcshjsx").attr("disabled",true);
        		}
        		if(",02,04,05,18,12,13,".indexOf(","+stepcode+",")!=-1){
        			if(stepcode=="04"){
        				//$("#m_kfpdyy").parent().hide();
        				$("#m_ddkskf").parent().hide();
        				$("#m_ddjskf").parent().hide();
        			}else if(stepcode=="05"){
        				//$("#m_cspdyy").parent().hide();
        				$("#m_ddksyw").parent().hide();
        				$("#m_ddjs").parent().hide();
        			}else if(stepcode=="18"){
        				//$("#m_yypdyy").parent().hide();
        				$("#m_ddjscs").parent().hide();
        				$("#m_ddkscs").parent().hide();
        			}
        			$("#changeUserBtn").show();
        		}else{
        			$("#changeUserBtn").prev().get(0).style.paddingRight="80px";
        		}
        	}
        };
        
		/*Ajax获取数据绑定到页面对应元素*/
		function getInfomation(user) {
        	baseAjax({
        		pattern:'http://getFlowInfo',
        		data:user,
        		isBlock:false,
        		success:'successFunctionH',
        		error:'failFunctionH'
        	});
        } 
        /*ajax成功回调方法*/
        function successFunctionH(ajax){
        	if (ajax.responseText.indexOf("系统session超时") != -1) {
                 B.alert("提示", "系统session超时,请重新登录", function() {
                       nativePage.executeScript("back()");
                 });
            }else{
			  	var objData = eval("("+ajax.responseText+")");
			  	if (objData != null) {
	                //console.log(objData);
	                flowid = objData.flowid;
	                flowexpid = objData.flowexpid;
	                stepid = objData.stepid;
	                stepexpid = objData.stepexpid;
	                objectID = objData.objectid;
	                objecttype = objData.objecttype;
	                formtype = objData.formtype;
	                formid = objData.formid;
	                fid = objData.fid;
	                steptype = objData.steptype;
	                userid = objData.userid;
	                username = objData.username;
	                stepUserSelect = objData.stepUserSelect;
	                //获取节点对象数组
	                var groups = objData.workItemlist;
	                for (var i = 0; i < groups.length; i++) {
	                    var Defaultwrap = groups[i].Defaultwrap; //节点是否默认展开
	                    var Sequencekey = parseInt(groups[i].Sequencekey) - 1; //节点在表单中顺序
	                    if ($("#group_id_" + Sequencekey).get(0) != undefined && Defaultwrap == 1 && Sequencekey !=
	                        1) { //节点在页面存在并默认展开时
	                        var group_id_1 = $("#group_id_1");
	                        var group_id_new = $("#group_id_" + Sequencekey);
	                        group_id_new.children(":first").children(":first").css('display','inline-block');
	                        $("#group_id_" + Sequencekey).remove();
	                        group_id_new.replaceAll("#group_id_1");
	                        $("#groupInfo").children(":first").before(group_id_1);
	                        group_id_1.children(":first").children(":first").css('display','none');
	                    }
	                    //节点对象下字段数组
	                    var fieldlist = groups[i].fieldlist;
	                    for (var j = 0; j < fieldlist.length; j++) {
	                        var field = fieldlist[j];
	                        setFieldInfo(field);//设置字段属性
	                    }
	                }
	                getStepUserList();//获取步骤处理人
	                bindFieldEvent();//给字段绑定方法
	            }
	            // 列表点击收缩
	            $(".group").click(function() {
	                $(this).next().slideToggle();
	                $(this).find('i').toggleClass('icon-arrowdown');
	                $(this).find('i').toggleClass('icon-arrowright');
	                // $(this).parent().siblings().children('ul').removeClass('hover').slideUp();
	            });
	            $("#ListElementHead").children(":first").next().children(":first").click();
	            }
	            layer.closeAll();
		}	
		/*ajax失败回调方法*/	  
		function failFunctionH(ajax){
		  	if (ajax.responseText.indexOf("系统session超时") != -1) {
                 B.alert("提示", "系统session超时,请重新登录", function() {
                       nativePage.executeScript("back()");
                 });
            } else {
                 B.alert("提示", "请求数据失败");
            } 
		}  
		
		/*定义一个数组，记录需要页面所有的字段*/
        var checkFieldList = new Array();
        var list = [];
        /*设置字段属性*/
        function setFieldInfo(field) {
            var obj = $("#" + field.filedname);
            if (obj.get(0) != undefined) {
                checkFieldList.push(field.filedname);
                obj.val(field.value);
                obj.attr("hidID", field.hidvalue);
           //   obj.attr("placeholder", "请填写" + field.title);
                obj.attr("propertyText", field.title);
                obj.attr("propertyType", field.datatype);
                obj.attr("mustInput", field.inputtype);
                if (field.inputtype == 0) {
                    obj.attr("disabled", true);
                    if (obj.get(0).tagName == "SELECT") {
                        obj.addClass("inputRead");
                    } else {
                        obj.attr("class", "inputRead");
                    }
                } else if (field.inputtype == 2) {
                    if (obj.get(0).tagName == "TEXTAREA") {
                        //obj.attr("class", "textareaWrite");
                        obj.prev().append('<span class="lableMust"></span>');
                    } else if (obj.get(0).tagName == "SELECT") {
                        //obj.addClass("inputWrite");
                        obj.parent().prev().append('<span class="lableMust"></span>');
                    } else {
                        //obj.attr("class", "inputWrite");
                        obj.prev().append('<span class="lableMust"></span>');
                    }
                    if(field.datatype==91){
                        obj.attr("readonly",true);
                        obj.get(0).onclick=function(){searchUser(field.filedname,false);return;};
                        obj.next().get(0).onclick=function(){searchUser(field.filedname,false);return;};
                    }
                } else if (field.inputtype == 1) {
                    if (obj.get(0).tagName == "TEXTAREA") {
                        obj.attr("class", "textareaNomal");
                    } else if (obj.get(0).tagName == "SELECT") {
                        //obj.addClass("inputNomal");
                    } else {
                        //obj.attr("class", "inputNomal");
                    }
                    if(field.datatype==91){
                        obj.attr("readonly",true);
                        obj.get(0).onclick=function(){searchUser(field.filedname,false);return;};
                        obj.next().get(0).onclick=function(){searchUser(field.filedname,false);return;};
                    }
                }
                obj.attr("systype", field.systype);
            } else {
                var fieldInfo = new Object();
                fieldInfo.fieldID = field.filedname; //属性id
                fieldInfo.fieldText = field.title; //显示名称
                fieldInfo.fieldType = field.datatype; //属性类型
                fieldInfo.fieldValue = field.value; //值
                var typeStr = "," + field.datatype + ",";
                if (',0,1,2,4,8,11,81,82,83,85,91,92,93,94,95,97,98,999,995,'.indexOf(typeStr) >= 0) {
                    if (',91,92,93,94,97,98,81,82,83,999,'.indexOf(typeStr) >= 0) {
                        fieldInfo.fieldValue = field.hidvalue;
                    } else {
                        fieldInfo.fieldValue = field.value || "";
                    }
                }
                fieldInfo.systype = field.systype; //是否系统属性
                list.push(fieldInfo);
                //流程附件单独处理
                if(field.filedname=="m_fj"){
                    for(var i=0;i<field.filelist.length;i++){
                        var filename = field.filelist[i].fileName+'.'+field.filelist[i].fileType;
                        var filesize = field.filelist[i].fileSize;
                        var fileid = field.filelist[i].fileID;
                        var filepath = field.filelist[i].filePath;
                        var str = '<div class="tab_big">'+
                                        '<span class="tab_spans" style="font-size:18px;" id="file_'+field.filelist[i].fileID+'">'+filename+'</br><span style="height:20px;width:100%;color:#408BCA;font-size:14px;">'+ filesize +'</span></span>'+
                                        //'<span class="tab_cha">'+
                                            //'<a id="file_'+field.filelist[i].fileID+'">查看</a>'+
                                        //'</span>'+
                                    '</div>';
                        $("#fileList").append(str);
                        eval('var fn=function(){downFile('+fileid+');return;}');
                        $("#file_"+field.filelist[i].fileID).get(0).onclick=fn;
                    }
                }
            }
        }
        
        /*给字段绑定方法*/
        function bindFieldEvent() {
            if (objecttype == "2590") { //项目申请
                if (stepcode == "02") { //需求受理人审核确认项目类别
                    document.getElementById("m_sfddzyxqsl").onchange = function() {
                        var bb = document.getElementById("m_sfddzyxqsl").value;
                        if ('0' == bb) {
                            document.getElementById("m_ddksxqsl").value = sysdate;
                        } else {
                            document.getElementById("m_ddksxqsl").value = '';
                        }
                        changeButton(bb,"m_sfddzyxqsl");
                    }
                } else if (stepcode == '04') {
                	if($('#m_kfpdyy').val() == ""){
                		$("#m_kfpdyy").parent().hide();
                	}
                    document.getElementById("m_sfddzykf").onchange = function() {
                        var bb = document.getElementById("m_sfddzykf").value;                
                        if ('0' == bb) {
                            document.getElementById("m_ddkskf").value = sysdate;
                        } else {
                        	$("#m_kfpdyy").parent().hide();
                            document.getElementById("m_ddkskf").value = '';
                        }
                        changeButton(bb,"m_sfddzykf");
                    }
                } else if (stepcode == '05') {
                	if($('#m_yypdyy').val() == ""){
                		$("#m_yypdyy").parent().hide();
                	}
                    var aa = document.getElementById("m_sfddzyyw").value;
                    if ('0' == aa) {
                        document.getElementById("m_ddksyw").value = sysdate;
                    }
                    document.getElementById("m_sfddzyyw").onchange = function() {
                        var bb = document.getElementById("m_sfddzyyw").value;
                        if ('0' == bb) {
                            $('#m_ddksyw').val(sysdate);
                        } else {
                        	$("#m_yypdyy").parent().hide();
                            document.getElementById("m_ddksyw").value = '';
                        }
                        changeButton(bb,"m_sfddzyyw");
                    }
                } else if (stepcode == '18') {
                	if($('#m_cspdyy').val() == ""){
                		$("#m_cspdyy").parent().hide();
                	}
                    document.getElementById("m_sfddzycs").onchange = function() {
                        var bb = document.getElementById("m_sfddzycs").value;
                        if ('0' == bb) {
                            document.getElementById("m_ddjscs").value = sysdate;
                        } else {
                        	$("#m_cspdyy").parent().hide();
                            document.getElementById("m_ddjscs").value = '';
                        }
                        changeButton(bb,"m_sfddzycs");
                    }
                }
            }
        }
        /*是否等待资源,切换按钮*/
        function changeButton(val,fieldID){
        	if(val=="0"){
        		var title = '提示';
        		var str = '进入资源排队，确定保存该流程?';
        		if(objecttype==2590&&(stepcode=="04"||stepcode=="05"||stepcode=="18")){
        			title = '资源排队原因';
        			str = '<textarea id="opinion_note" style="width:94.8%;margin:0;border:none;-webkit-user-select: auto !important;-webkit-touch-callout: none !important;" cols="10" rows="6" placeholder="请填写资源排队原因"></textarea>';
        		}
	        	B.confirm(title,str,
	                function() {
	                	if(objecttype==2590){
	                		if(stepcode=="04"){
	                			var note = $.trim($("#opinion_note").val());
	                			$("#m_kfpdyy").val(note);
	                		}else if(stepcode=="05"){
	                			var note = $.trim($("#opinion_note").val());
	                			$("#m_yypdyy").val(note);
	                		}else if(stepcode=="18"){
	                			var note = $.trim($("#opinion_note").val());
	                			$("#m_cspdyy").val(note);
	                		}
	                	}
	                    save('');
	                },
	                function() {
	                	document.getElementById(fieldID).value="1";
						document.getElementById(fieldID).onchange();
	                });
        	}
        }
        /*获取步骤以及步骤处理人*/
        function getStepUserList() {
            var dataObj = new Object();
            dataObj.flowid = flowid;
            dataObj.flowexpid = flowexpid;
            dataObj.stepid = stepid;
            dataObj.stepexpid = stepexpid;
            dataObj.objectid = objectID;
            dataObj.objecttype = objecttype;
            dataObj.formtype = formtype;
            dataObj.formid = formid;
            dataObj.fid = fid;
            
            baseAjax({
        		pattern:'http://getStepUserList',
        		data:dataObj,
        		isBlock:false,
        		success:'successFunctionI',
        		error:'failFunctionI'
        	});
        }
        
        function successFunctionI(ajax){
                    var res = eval("("+ajax.responseText+")");
                    //console.log(res);
                    //后续步骤处理人
                    if (res.success == false) {
                        $("#steplist_section").hide();
                    } else {
                        $("#steplist_section").show();
                        //项目申请
                        if (objecttype == "2590") {
                            if (stepcode == "03") {
                                if ($("#m_wcshjsx").val() == 1) {
                                    res.root2[2].abailableuser = res.root2[1].abailableuser;
                                }
                                $("#m_wcshjsx").unbind("change", getStepUserList);
                                $("#m_wcshjsx").change(getStepUserList);
                                genStepUserGrid(res.root2);
                                $("#02_user_tr").hide();
                            } else if ("04" == stepcode || "05" == stepcode || "18" == stepcode) {
                                genStepUserGrid(res.root2);
                                get04XmsqClr();
                            } else if ("08" == stepcode) {
                                genStepUserGrid(res.root2);
                                $("#11_user_tr").hide();
                                $("#06_user_tr").hide();
                            } else if ("12" == stepcode) {
                                genStepUserGrid(res.root2);
                                // 判断当"项目等级"是“A”的时候只显示“业务线领导审批”，“B”的时候只显示“立项审批”，“C”的时候只显示“需求人受理”
                                var m_xmdj = "0";//0-无
                                if (document.getElementById("m_xmdj")) {
                                    m_xmdj = document.getElementById("m_xmdj").value; // 1 A ;2 B; 3 C 
                                }
                                var m_xmlb = document.getElementById("m_xmlb").value; // 1 开发；0 支持
                                var ob4 = document.getElementById("08_user_tr");
                                if (ob4) ob4.style.display = 'none';
                                var obj0 = document.getElementById("13_user_tr");
                                var obj1 = document.getElementById("16_user_tr");
                                var obj2 = document.getElementById("17_user_tr");
                                //typeof obj=="object"
                                if ("1" == m_xmlb) {
                                    if ("1" == m_xmdj) {
                                        if (obj0) obj0.style.display = '';
                                        if (obj1) obj1.style.display = 'none';
                                        if (obj2) obj2.style.display = 'none';
                                        getYcbzbh("13");
                                    } else if ("2" == m_xmdj) {
                                        if (obj0) obj0.style.display = 'none';
                                        if (obj1) obj1.style.display = '';
                                        if (obj2) obj2.style.display = 'none';
                                        getYcbzbh("16");
                                    } else {
                                        if (obj0) obj0.style.display = 'none';
                                        if (obj1) obj1.style.display = 'none';
                                        if (obj2) obj2.style.display = '';
                                        getYcbzbh("17");
                                    }
                                } else if ("0" == m_xmlb) {
                                    if (obj0) obj0.style.display = 'none';
                                    if (obj1) obj1.style.display = 'none';
                                    if (obj2) obj2.style.display = '';
                                    getYcbzbh("17");
                                }
                                get12XmsqClr();
                            } else if ("13" == stepcode) {
                                genStepUserGrid(res.root2);
                                var ob1 = document.getElementById("12_user_tr");
                                if (ob1) ob1.style.display = 'none';
                                getYcbzbh("14");
                            } else if ("16" == stepcode) {
                                genStepUserGrid(res.root2);
                                var ob1 = document.getElementById("11_user_tr");
                                if (ob1) ob1.style.display = 'none';
                                getCfgWfsStepId("17");
                                getYcbzbh("17");
                                get16XmsqClr();
                            } else {
                                genStepUserGrid(res.root2);
                            }
                        } else {
                            genStepUserGrid(res.root2);
                        }
                    }
        }
        function failFunctionI(ajax){
        	if (e.responseText.indexOf("系统session超时") != -1) {
                   B.alert("提示", "系统session超时,请重新登录", function() {
                        nativePage.executeScript("back()");
                   });
            } else {
                   B.alert("提示", "请求数据失败");
            }
        }
        /*构造预设处理步骤和预设处理人*/
        function genStepUserGrid(stepArr) {
            $('tr[name="stepuserList"]').remove();
            //console.log(stepArr);
            for (var i = 0; i < stepArr.length; i++) {
            	if(objecttype==2590&&(stepcode=="08"||stepcode=="12")){
        			if(4==stepArr[i].initusertype){
        				var userArr = stepArr[i].abailableuser; 
        				stepArr[i].abailableuser = []; // 把流程用户组置空
						var resArr = stepArr[i].abailableuser;
						for(var j=0;j<userArr.length;j++){
							for(var k=0;k<stepUserSelect.length;k++){
								if(userArr[j].userid==stepUserSelect[k].userid){
									resArr.push({userid:userArr[j].userid,username:userArr[j].username,departmentname:userArr[j].departmentname});
								}
							}
						}
						if(resArr.length==1){
        					stepArr[i].userid = resArr[0].userid;
        					stepArr[i].username = resArr[0].username;
        				}
        			}
        		}
                var stepStr = '<tr name="stepuserList" id="' + stepArr[i].stepcode +
                    '_user_tr"><td class="input-group-lg">' + stepArr[i].stepname + '</td>' +
                    '<td></td>' +
                    '<td>' +
                    '   <input class="input-item" id="step_' + stepArr[i].stepid +
                    '_user" type="text" readOnly usermode="' + stepArr[i].usermode + '" stepid="' + stepArr[i].stepid +
                    '" mustinput="' + stepArr[i].mustinput + '" hidID="' + stepArr[i].userid + '" value="' + stepArr[i]
                    .username + '">' +
                    '   <span id="step_' + stepArr[i].stepid + '_span">' +
                    '       <img src="assets/app/img/icon_33.png">' +
                    '   </span>' +
                    '</td></tr>';
                $("#stepuserListTable").append(stepStr);
                if (stepArr[i].initusertype == 0) { //
                    eval('var fn=function(){getUserData(stepArr[' + i + '].stepid,0,20501);return;}');
                } else {
                    eval('var fn=function(){showStepUser(stepArr[' + i + '].stepid,stepArr[' + i + '].abailableuser,1);return;}');
                }
                $("#step_" + stepArr[i].stepid + "_span").get(0).onclick = fn;
                $("#step_" + stepArr[i].stepid + "_user").get(0).onclick = fn;
            }
        }
        var searchTextOld = "";
        /*展示预设处理人查询页面*/
        function showStepUser(stepid, abailableuser, type) {
        	var searchText = $('#preset_stepuser_span').prev().val();
        	if($("#pop_custom1").css("display")!="none"&&$('tr[name="abailableuser_tr"]').length!=0&&searchTextOld==searchText){
        		return;
        	}else{
        		searchTextOld = searchText;
        	}
            $('tr[name="abailableuser_tr"]').remove();
            var selectedUser = $("#step_" + stepid + "_user").attr("hidID");
            var jsparamTemp = jsparam;
            for (var i = 0; i < abailableuser.length; i++) {
            	if(jsparam>jsparamTemp){
            		return;
            	}
                var stepuser = abailableuser[i];
                if(stepuser.userjp==undefined){
                	$("#pinyin").val(stepuser.username);
                	stepuser.userjp=$("#pinyin").toPinyin().toLowerCase();
                }
                var selectedFlag = "";
                if (("," + selectedUser + ",").indexOf("," + stepuser.userid + ",") != -1) {
                    selectedFlag = "checked";
                }
                
                if (searchText != "" && stepuser.username.indexOf(searchText) == -1&&stepuser.userjp.indexOf(searchText.toLowerCase()) != 0) {
                    continue;
                }
                if(stepuser.username.indexOf('administrator') > -1 || stepuser.username.indexOf('PMOmanager') > -1 || stepuser.username.indexOf('user') > -1 || stepuser.username.indexOf('安全可控') > -1){
		             continue;
		       	}
                var str = '<tr name="abailableuser_tr"><td>' +
                    '    <input name="abailableuser" type="checkbox" hidID="' + stepuser.userid + '" val="' + stepuser.username +
                    '" ' + selectedFlag + '>' +
                    '</td><td>' + stepuser.username + '</td><td>'+ stepuser.departmentname +'</td></tr>';
                //((type==2&&searchText != "")||type==1)  预设处理人为空隐藏 
                 if(type==2||type==1){
                	$("#preset_stepuser_table").append(str);
                }
            }
            $('input[name="abailableuser"]').click(function(){
                    var val = $(this).attr("hidID");
                    $('input[name="abailableuser"]:checked').each(function(){
                        if(val!=$(this).attr("hidID")){
                            $(this).attr("checked", false);
                        }else{
                            $(this).attr("checked", true);
                        }
                    });
            })
            $('#pop_custom1').show();
            $('#preset_stepuser_span').get(0).onclick = function() {
                if (type != 1) {
                    getUserData(stepid, 0, 20501);
                } else {
                    showStepUser(stepid, abailableuser, type);
                }
                return;
            };
            $('#preset_stepuser_input').get(0).onkeydown=function(){
                jsparam++;
            }
            $('#preset_stepuser_input').get(0).onkeyup=function(){
            	$('#preset_stepuser_span').get(0).onclick();
                return;
            }
            $('#preset_stepuser_ensure').get(0).onclick = function() {
                setStepUser(stepid);
                return
            };
        }
        /*回填选择的预设处理人*/
        function setStepUser(stepid) {
            var user = new Object();
            user.userid = "";
            user.username = "";
            $('input[name="abailableuser"]:checked').each(function() {
                if (user.userid != "") {
                    user.userid += ","
                }
                if (user.username != "") {
                    user.username += ","
                }
                user.userid += $(this).attr("hidID");
                user.username += $(this).attr("val");
            });
            $("#step_" + stepid + "_user").attr("hidID", user.userid);
            $("#step_" + stepid + "_user").val(user.username);
            $('#pop_custom1').hide();
            return;
        }
        
        var flowUserList = [];
        function getUserData(stepid, roleID, componentID) {
            if(flowUserList.length==0){
            	baseAjax({
	        		pattern:'http://searchUser',
	        		data:{method:'searchUser',roleID:roleID,componentID:componentID,userName:''},
	        		isBlock:false,
	        		success:'successFunctionJ',
	        		error:'failFunctionJ',
	        		relydata:{stepid:stepid}
	        	});
            }else{
	            showStepUser(stepid, flowUserList, 2);
            }
        }
        
        function successFunctionJ(ajax){
        	var data = eval('('+ajax.responseText+')');
        	if (data.success) {
                  flowUserList = data.root;
                  var relydata = JSON.parse(ajax.getStringData("relydata"));
                  showStepUser(relydata.stepid, flowUserList, 2);
            }
        }
        function failFunctionJ(ajax){
        	
        }
        
        function get04XmsqClr() {
        	baseAjax({
	        		pattern:'http://getValueBysql',
	        		data:{
	                    'type': 11,
	                    'cs1': flowexpid,
	                    'csnum': 2,
	                    'cs2': flowid
                	},
	        		isBlock:false,
	        		success:'successFunctionK',
	        		error:'failFunctionK'
	        });
        }
        function successFunctionK(ajax){
        	var data = ajax.responseText;
        	var rtndata = data.trim().split("~");
            $('#03_user_tr').hide();
            $('#step_' + 646 + '_user').attr("hidID", rtndata[0]);
            $('#step_' + 646 + '_user').val(rtndata[1]);
        }
        function failFunctionK(ajax){
        	
        }

        function getCfgWfsStepIdXXX(currentcode) {
        	baseAjax({
	        		pattern:'http://getCfgWfsStepId',
	        		data:{
	                    'flowid': flowid,
	                    'stepcode': currentcode
                	},
	        		isBlock:false,
	        		success:'successFunctionL',
	        		error:''
	        });
        }
        function successFunctionL(ajax){
        	nextstepidh = eval("("+ajax.responseText+")");
        }

        function getYcbzbh(ccode) {
            getCfgWfsStepIdXXX(ccode);
            ycbzbh = nextstepidh;
        }

        function getCfgWfsStepId(currentCode) {
        	baseAjax({
	        		pattern:'http://getCfgWfsStepId',
	        		data:{
	                    'flowid': flowid,
	                    'stepcode': currentCode
                	},
	        		isBlock:false,
	        		success:'successFunctionM',
	        		error:''
	        });
        }
        function successFunctionM(ajax){
        	var rs = eval("("+ajax.responseText+")")
            nextstepid = rs;
            nextstepid2 = rs;
            nextstepid3 = rs;
        }

        function get12XmsqClr() {
            if ("0" == $("#m_xmlb").val() || ("1" == $("#m_xmlb").val() && "3" == $("#m_xmdj").val())) { //当是支持类、或者（开发类，项目等级为C）的时候才会到需求受理人立项
                getCfgWfsStepId("17");
                baseAjax({
	        		pattern:'http://getValueBysql',
	        		data:{
	                    'type': 16,
                    	'cs1': flowexpid,
                    	'csnum': 2,
                    	'cs2': flowid
                	},
	        		isBlock:false,
	        		success:'successFunctionN',
	        		error:''
	        	});
            }
        }
        function successFunctionN(ajax){
        	var data = ajax.responseText;
        	var rtndata = data.trim().split("~");
        	$('#step_' + nextstepid3 + "_user").attr("hidID", rtndata[0]);
            $('#step_' + nextstepid3 + "_user").val(rtndata[1]);
        }
        // 立项审批时候进行“需求受理人立项”处理人设置
        function get16XmsqClr() {
        	baseAjax({
	        		pattern:'http://getValueBysql',
	        		data:{
	                    'type': 18,
                    	'cs1': flowexpid,
                    	'csnum': 2,
                    	'cs2': flowid
                	},
	        		isBlock:false,
	        		success:'successFunctionO',
	        		error:''
	        });
        }
        function successFunctionO(ajax){
        	var data = ajax.responseText;
        	var rtndata = data.trim().split("~");
        	$('#step_' + nextstepid + "_user").attr("hidID", rtndata[0]);
            $('#step_' + nextstepid + "_user").val(rtndata[1]);
        }
        
        var userList = [];
        function searchUser(fieldname, isMulti) {
            if(userList.length==0){
            	baseAjax({
	        		pattern:'http://searchUser',
	        		data:{method:'searchUser',roleID:0,componentID:0,userName:''},
	        		isBlock:true,
	        		success:'successFunctionP',
	        		error:'',
	        		relydata:{fieldname:fieldname,isMulti:isMulti}
	        	});
            }else{
                genUserGrid('pop_custom2', fieldname, isMulti, userList);
            } 
        }
        function successFunctionP(ajax){
        	var data = eval('('+ajax.responseText+')');
        	if (data.success) {
        		   var relydata = JSON.parse(ajax.getStringData("relydata"));
                   genUserGrid('pop_custom2', relydata.fieldname, relydata.isMulti, data.root); 
                   userList = data.root;
            }
        }
		var searchText_old = "";
        function genUserGrid(gridname, fieldname, isMulti, userArr) {
        	var searchText = $('#' + gridname + '_span').prev().val();
        	if($("#"+gridname).css("display")!="none"&&$('tr[name="' + gridname + '_tr"]').length!=0&&searchText_old==searchText){
        		return;
        	}else{
        		searchText_old = searchText;
        	}
            $('tr[name="' + gridname + '_tr"]').remove();	       
            var selectedUser = $("#" + fieldname).attr("hidID");
            var jsparamTemp = jsparam;
            for (var i = 0; i < userArr.length; i++) {
            	if(jsparam>jsparamTemp){
            		return;
            	}
                var stepuser = userArr[i];
                if(stepuser.userjp==undefined){
                	$("#pinyin").val(stepuser.username);
                	stepuser.userjp=$("#pinyin").toPinyin().toLowerCase();
                }
                var selectedFlag = "";
                if (("," + selectedUser + ",").indexOf("," + stepuser.userid + ",") != -1) {
                    selectedFlag = "checked";
                }
                if (searchText != "" && stepuser.username.indexOf(searchText) == -1&&stepuser.userjp.indexOf(searchText.toLowerCase()) != 0) {
                    continue;
                }
                if(stepuser.username.indexOf('administrator') > -1 || stepuser.username.indexOf('PMO') > -1){
                	continue;
                }
                if(fieldname == 'm_kffzr'){
		        	var kffzr = '软件开发部';
		        	if(stepuser.departmentname.indexOf(kffzr) == -1){
		        		continue;
		        	}
		        };
		        if(fieldname == 'm_csfzr'){
		        	var kffzr = '软件开发部系统测试室';
		        	if(stepuser.departmentname.indexOf(kffzr) == -1){
		        		continue;
		        	}
		        }
		        if(fieldname == 'm_yweidb'){
		        	var kffzr = '系统运营部';
		        	if(stepuser.departmentname.indexOf(kffzr) == -1){
		        		continue;
		        	}
		        }
                var str = '<tr name="' + gridname + '_tr"><td>' +
                    '    <input name="' + gridname + '_input" type="checkbox" hidID="' + stepuser.userid + '" val="' + stepuser.username +
                    '" ' + selectedFlag + '>' +
                    '</td><td>' + stepuser.username + '</td><td>'+ stepuser.departmentname +'</td></tr>';
                 $('#'+gridname+'_table').append(str); 
                 
            }
            
            // 开发、运维、测试负责人隐藏
            //if(searchText == ""){
                //$('tr[name="' + gridname + '_tr"]').remove();
            //}
            if(!isMulti){
                $('input[name="'+gridname+'_input"]').click(function(){
                    var val = $(this).attr("hidID");
                    $('input[name="'+gridname+'_input"]:checked').each(function(){
                        if(val!=$(this).attr("hidID")){
                            $(this).attr("checked", false);
                        }else{
                            $(this).attr("checked", true);
                        }
                    });
                })
            }
            $('#'+gridname).show();
            $('#'+gridname+'_span').get(0).onclick = function() {
                genUserGrid(gridname, fieldname, isMulti, userArr);
                return;
            };
            $('#'+gridname+'_input').get(0).onkeydown=function(){
                jsparam++;
            }
            $('#'+gridname+'_input').get(0).onkeyup=function(){
            	$('#'+gridname+'_span').get(0).onclick();
                return;
            }
            $('#'+gridname+'_ensure').get(0).onclick = function() {
                setUserValue(gridname,fieldname);
                return
            };
        }
        function setUserValue(gridname,fieldname){
            var user = new Object();
            user.userid="";
            user.username="";
            $('input[name="'+gridname+'_input"]:checked').each(function(){
                if (user.userid != "") {
                    user.userid += ","
                }
                if (user.username != "") {
                    user.username += ","
                }
                user.userid += $(this).attr("hidID");
                user.username += $(this).attr("val");        
            });
            $("#"+fieldname).attr("hidID",user.userid);
            $("#"+fieldname).val(user.username);
            $('#'+gridname).hide();
        }
        
        //附件下载
        function downFile(fileid){
        	baseAjax({
	        		pattern:'http://getFilePath',
	        		data:{method:'checkfile',fileid:fileid},
	        		isBlock:true,
	        		success:'successFunctionQ',
	        		error:'',
	        		relydata:{fileid:fileid}
	        }); 
        }
        function successFunctionQ(ajax){
        	var res = eval("("+ajax.responseText+")");
        	var relydata = JSON.parse(ajax.getStringData("relydata"));
        	if(!res.success){
                  B.alert("提示",res.msg);
            }else{  
                  nativePage.executeScript("doClick_A("+relydata.fileid+",'"+res.filename+"')");        
            }
        }
        
        
        
		
		     
