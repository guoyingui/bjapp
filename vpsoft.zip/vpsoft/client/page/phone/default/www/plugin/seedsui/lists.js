//  下拉刷新
    var mescroll;
	//加载完毕后触发plusready事件
    document.addEventListener("plusready",function(){
        mescroll = new MeScroll("mescroll", { //第一个参数"mescroll"对应上面布局结构div的id
	        //如果您的下拉刷新是重置列表数据,那么down完全可以不用配置,具体用法参考第一个基础案例
	        //解析: down.callback默认调用mescroll.resetUpScroll(),而resetUpScroll会将page.num=1,再触发up.callback
	        down: {
	            // auto:false,
	            clearEmptyId: "dataList",
	            callback: downCallback,
	            // autoShowLoading: false
	             //下拉刷新的回调,别写成downCallback(),多了括号就自动执行方法了
	        },
	        up: {
                use: false
	            // callback: upCallback
	        }
    	});
    },false);
    //下拉加载的回调 page = {num:1, size:10}; num:当前页 默认从1开始, size:每页数据条数,默认10
    function downCallback() {//filterId=5;表示查询所有待处理流程
    	baseAjax({
    		pattern:"http://searchFlowList",
    		method:"post",
    		data:{filterId:5},
    		isBlock:true,
    		success:"successFunction",
    		error:"failFunction"
    	});
    };
    var jsparam = 0;  //计数
    function successFunction (ajax){
		var data = eval("("+ajax.responseText+")");
		mescroll.endSuccess();  
		$('.pend_list ul').empty().not($(this));
        var mylists = data.listData;
        listData(mylists);
        
        //待处理查找功能
        $('.sech_ipt').get(0).onkeydown=function(){
	         jsparam++;
	    }
		$('.sech_icn').get(0).onclick=function () {
	        $('.pend_list ul').empty().not($(this));
	         listData(mylists);
	    };
	    $('.sech_ipt').get(0).onkeyup=function(){
	         $('.sech_icn').get(0).onclick();
	         return;
	    }
	}
	function failFunction (ajax){
		//联网失败的回调,隐藏下拉刷新和上拉加载的状态
        mescroll.endErr();
	}
	function upCallback(){
		mescroll.endSuccess();
	}

function listData(data){
    if (data == undefined) {
        B.alert("提示", "系统session超时,请重新登录", function() {
            nativePage.executeScript("back()");
        });
        return false;
    }
    var jsparamTemp = jsparam;
    var searchvalues = $('.sech_ipt').val();
    for (var index = 0; index < data.length; index++) {
        var element = data[index];
        var steps = element.steps;
        for (var pop = 0; pop < steps.length; pop++) {
        	if(jsparam>jsparamTemp){
             	return;
        	}
            var steps_pop = steps[pop];
            if(element.objectnamepy==undefined){
	             $("#flowLabel").val(element.objectname);
	             element.objectnamepy=$("#flowLabel").toPinyin().toLowerCase();
	             $("#flowLabel").val(element.flowname);
	             element.flownamepy=$("#flowLabel").toPinyin().toLowerCase();
        	}
            var flowid = element.flowid;
            var flowexpid = element.flowInsId;
            var stepid = steps_pop.stepid;
            var stepexpid = steps_pop.stepInsId;
            var objectid = element.objectid;
            var objecttype = element.objecttype;
            var stepcode = steps_pop.stepcode;
            var steptype = steps_pop.steptype;
            
            if (searchvalues != "" && element.flowname.indexOf(searchvalues) == -1&& element.objectname.indexOf(searchvalues) == -1 
			&& element.objectnamepy.indexOf(searchvalues.toLowerCase()) != 0 &&element.flownamepy.indexOf(searchvalues.toLowerCase()) != 0) {
	            continue;
	        }
            if (steptype == '4') {
                $('.pend_list ul').append(
                    '<li class="list"><div class="pend_mide" style="transition-duration: 0.3s; transform: translate3d(0px, 0px, 0px);" onclick=" parallel(' + flowid + ',' + flowexpid + ',' + stepid + ',' + stepexpid + ',' + objectid + ',' + objecttype + ',' + steptype + ',\'' + stepcode + '\')">' +
                    '<figure class="pd_icnl"></figure>' +
                    '<hgroup><h4>' +
                    element.flowname + '</h4>' +
                    '<p class="hgroup">' + element.objectname + '</p>' +
                    '<p><span class="element">' + steps_pop.stepname + '</span><time>' + steps_pop.startdate + '</time></p></hgroup></div>' +
                    '<div class="subListTitle right"><span style="border-right: 1px solid #fff;" class="subRight" onclick="saveEnsure(\'SYS_REFUSE\',this)"><img src="assets/app/img/icon_8.png" alt=""></span><span class="subRight" onclick="saveEnsure(\'SYS_AGREE\',this)"><img src="assets/app/img/icon_30.png" alt=""></span></div></li>')
            }
            else{
                $('.pend_list ul').append(
                    '<li class="list"><div class="pend_mide" style="transition-duration: 0.3s; transform: translate3d(0px, 0px, 0px);" onclick=" parallel(' + flowid + ',' + flowexpid + ',' + stepid + ',' + stepexpid + ',' + objectid + ',' + objecttype + ',' + steptype + ',\'' + stepcode + '\')">' +
                    '<figure class="pd_icnl"></figure>' +
                    '<hgroup><h4>' +
                    element.flowname + '</h4>' +
                    '<p class="hgroup">' + element.objectname + '</p>' +
                    '<p><span class="element">' + steps_pop.stepname + '</span><time>' + steps_pop.startdate + '</time></p></hgroup></div>' +
                    '<div class="subListTitle right"><span class="subRight" onclick="saveEnsure(\'SYS_PROCESS\',this)"><img src="assets/app/img/icon_29.png" alt=""></span></div></li>')
            }
            
        }
    };
    if($(".list").length == 0){
		 $('.pend_list ul').append(
	     		'<li class="pend_shuju">没有搜索到数据</li>'
	    )
	};
    var list = document.getElementsByClassName("list");
	for (var i = 0; i < list.length; i++) {
		list[i].addEventListener("touchstart",touch, false);
		list[i].addEventListener("touchmove",touch, false);
		list[i].addEventListener("touchend",touch, false);
    }
    var pendmide = document.getElementsByClassName("pend_mide");
    for (var i = 0; i < pendmide.length; i++) {
        pendmide[i].addEventListener("touchstart", function (event) {
            var thises = window.getComputedStyle(event.currentTarget, "").transform;
            thises = Math.abs(Number(thises.substring(7, thises.length - 1).split(",")[4]));
            if (thises == 0) {
                var pendmide = document.getElementsByClassName("pend_mide");
                for (var i = 0; i < pendmide.length; i++) {
                    pendmide[i].style.transform = 'translate3d(0px,0px, 0px)';
                }
            }
            event.currentTarget.style.backgroundColor = "#D9D9D9";
        }, false);

        pendmide[i].addEventListener("touchmove", function (event) {
            event.currentTarget.style.backgroundColor = "white";
        }, false);

        pendmide[i].addEventListener("touchend", function (event) {
            event.currentTarget.style.backgroundColor = "white";
        }, false);
    }
}
var clickListFlag = true;
var userData ;
var elementChecked;
var dataObj;
function parallel(flowid, flowexpid, stepid, stepexpid, objectid, objecttype, steptype, stepcode) {
    userData = {
        flowid: flowid,
        flowInsId: flowexpid,
        stepid: stepid,
        stepInsId: stepexpid,
        objectid: objectid,
        objecttype: objecttype,
        steptype: steptype,
        stepcode: stepcode
    };    
    // 页面之间传值
    var user = JSON.stringify(userData);
    if(clickListFlag){
    	if(objecttype == "2590"){
    		window.location.href = 'pagename.html?data=' + user;
    	}
    	else if(objecttype == "2591"){
    		window.location.href = 'ApplyOnline.html?data=' + user;
    	}
    	else if(objecttype == "2592"){
    		window.location.href = 'Requirement.html?data=' + user;
    	}
    	else if(objecttype == "1"){
    		window.location.href = 'Conclusion.html?data=' + user;
    	}else if(objecttype == "2594"){
    		window.location.href = 'Suspended.html?data=' + user;
    	}
    	else if(objecttype == "2596"){
    		window.location.href = 'Canceled.html?data=' + user;
    	}
    	else if(objecttype == "2595"){
    		window.location.href = 'restart.html?data=' + user;
    	}
    	
    }
    clickListFlag = true;
}
function setIframeInfo(element){
    clickListFlag = false;
	element.onclick();
}
function saveEnsure(opinionVal,element) {
	userData.opinionVal=opinionVal;
	elementChecked = element;
	baseAjax({
	    	pattern:"http://flowInfoAction",
	    	method:"post",
	    	data:userData,
	    	isBlock:true,
	    	success:"successFunction2",
	    	error:"failFunction2"
	});
}
function successFunction2(ajax){
	var data = eval("("+ajax.responseText+")");
	if(data.success){
		if(data.opinionVal == "SYS_REFUSE"){//只需要填写意见
	        B.confirm('拒绝处理意见', '<textarea id="opinion_note" style="width:94.8%;border:none;-webkit-user-select: auto !important;-webkit-touch-callout: none !important;" cols="10" rows="30" placeholder="请填写意见"></textarea>',function(){
	            var note = $("#opinion_note").val();
	            if($.trim(note)==""){
	                return false;
	            }
	            //写入意见
	            data.dataObj.note = $.trim(note);
	            if(data.noteindex!=-1){
	            	data.dataObj.fieldList[data.noteindex].fieldValue = $.trim(note)+'\n\n签批人:'+data.username;
	            }
	            if(data.noteindex2!=-1){
	            	data.dataObj.fieldList[data.noteindex2].fieldValue = $.trim(note)+'\n\n签批人:'+data.username;
	            }
	            dataObj = data.dataObj;
	            if(userData.objecttype==2590&&(userData.stepcode=="04"||userData.stepcode=="05"||userData.stepcode=="18")){
	                savesfddzy(data.m_sfddzykf,data.m_sfddzycs,data.m_sfddzyyw);           
	            }
	            if(userData.objecttype==2591 && userData.stepcode == "18"){
	                var sfbfsx = data.m_sfbfsx;
					var sfzzsx = data.m_sfzzsx;
					var zxsj = data.m_zxsj;
					var projectid  = data.m_xmmc;
					if(zxsj != ''){
						//1 是最终上线，将执行时间写入对应项目的高层计划的实际完成时间
						if(sfzzsx == '0'){
							baseAjax({
								pattern:'http://updatePhasedate',
								data:{'zxsj':zxsj,
			        			'projectid':projectid},
								isBlock:true,
								success:'successFunction_8',
								error:''
							});
						}
						
						//2 将是否部分上线、是否最终上线和执行时间值写入项目基本信息
						baseAjax({
							pattern:'http://updateToPjInfo',
							data:{'zxsj':zxsj,
							'sfbfsx':sfbfsx,
							'sfzzsx':sfzzsx,
							'projectid':projectid},
							isBlock:true,
							success:'successFunction_9',
							error:''
						});
					}
	            }
	            //【上线申请】执行人执行和验证人验证步骤的动作中取执行结果和验证结果必须先保存
				if(userData.objecttype=="2591" && (userData.stepcode == "18" || userData.stepcode == "22")){
					var sfwc = data.m_sfwc;
					var sftg = data.m_sftg;
					var objectid = data.objectid;
		            baseAjax({
		        		pattern:'http://saveSxresult',
		        		data:{'sfwc':sfwc,
		        			'sftg':sftg,
		        			'objectid':objectid},
		        		isBlock:true,
		        		success:'successFunction_10',
		        		error:''
		        	});
				}
	            baseAjax({
	        		pattern:'http://saveCfgFormAction',
	        		data:dataObj,
	        		isBlock:true,
	        		success:'successFunction_1',
	        		error:'failFunction_1'
	        	});
	            
	        },
	        function(){});
	    }else{
	    	data.dataObj.note = '同意';
	        if(data.noteindex!=-1){
	            data.dataObj.fieldList[data.noteindex].fieldValue = '同意\n\n签批人:'+data.username;
	        }
	        if(data.noteindex2!=-1){
	            data.dataObj.fieldList[data.noteindex2].fieldValue = '同意\n\n签批人:'+data.username;
	        }
	        dataObj = data.dataObj;
    		var text = "提交";
    		if (data.opinionVal == "SYS_AGREE") {
                text = "批准";
            }
	    	B.confirm("提示","确定"+text+"该流程?",function(){
	    		if(userData.objecttype==2590&&(userData.stepcode=="04"||userData.stepcode=="05"||userData.stepcode=="18")){
	                savesfddzy(data.m_sfddzykf,data.m_sfddzycs,data.m_sfddzyyw);           
	            }
	            if(userData.objecttype==2591 && userData.stepcode == "18"){
	                var sfbfsx = data.m_sfbfsx;
					var sfzzsx = data.m_sfzzsx;
					var zxsj = data.m_zxsj;
					var projectid  = data.m_xmmc;
					if(zxsj != ''){
						//1 是最终上线，将执行时间写入对应项目的高层计划的实际完成时间
						if(sfzzsx == '0'){
							baseAjax({
								pattern:'http://updatePhasedate',
								data:{'zxsj':zxsj,
			        			'projectid':projectid},
								isBlock:true,
								success:'successFunction_8',
								error:''
							});
						}
						
						//2 将是否部分上线、是否最终上线和执行时间值写入项目基本信息
						baseAjax({
							pattern:'http://updateToPjInfo',
							data:{'zxsj':zxsj,
							'sfbfsx':sfbfsx,
							'sfzzsx':sfzzsx,
							'projectid':projectid},
							isBlock:true,
							success:'successFunction_9',
							error:''
						});
					}
	            }
	            //【上线申请】执行人执行和验证人验证步骤的动作中取执行结果和验证结果必须先保存
				if(userData.objecttype=="2591" && (userData.stepcode == "18" || userData.stepcode == "22")){
					var sfwc = data.m_sfwc;
					var sftg = data.m_sftg;
					var objectid = data.objectid;
		            baseAjax({
		        		pattern:'http://saveSxresult',
		        		data:{'sfwc':sfwc,
		        			'sftg':sftg,
		        			'objectid':objectid},
		        		isBlock:true,
		        		success:'successFunction_10',
		        		error:''
		        	});
				}
                baseAjax({
	        		pattern:'http://saveCfgFormAction',
	        		data:dataObj,
	        		isBlock:true,
	        		success:'successFunction_1',
	        		error:'failFunction_1'
	        	});
            },
            function(){})
	    }
	}else{
		if(userData.opinionVal == "SYS_REFUSE" && userData.objecttype=="2591" && (userData.stepcode == "15" || userData.stepcode == "11")){
			B.confirm("提示",data.msg,function(){
                $(elementChecked).parent().prev().get(0).onclick();
            },
            function(){});
		}else if(data.msg.indexOf("必填项")!=-1||data.msg.indexOf("不能为空")!=-1||data.msg.indexOf("请选择")!=-1){
			B.confirm("提示",data.msg,function(){
                $(elementChecked).parent().prev().get(0).onclick();
            },
            function(){});
		}else{
			B.alert("提示",data.msg);
		}
	}
}
		function failFunction2(ajax){
			
		}
		function successFunction_1(ajax){
        	if(ajax.responseText.indexOf("系统session超时") != -1){
        		B.alert("提示", "系统session超时,请重新登录", function() {
                     nativePage.executeScript("back()");
                });
                return;
        	}
        	var res = eval("("+ajax.responseText+")");
        	//var relydata = JSON.parse(ajax.getStringData("relydata"));
        	//流程分支同步回退
            if(userData.objecttype==2590&&(userData.stepcode=="04"||userData.stepcode=="05"||userData.stepcode=="18")&&userData.opinionVal=="SYS_REFUSE"){
                syncFlowBack();
            }else if(userData.objecttype==1&&(userData.stepcode=="02"||userData.stepcode=="03")){
            	var m_wcsyxqgn = dataObj.m_wcsyxqgn;
        		var m_wcsyxqgnkf = dataObj.m_wcsyxqgnkf;
        		if(m_wcsyxqgn==2||m_wcsyxqgnkf==2){//任意一个选择否，将另有一个并行步骤自动提交
        			getBXFZ();
        		}else{//都选是，切换项目状态
        			changePJStat();
        		}
            }else{
            	B.alert("提示", "操作成功", function() {
                        $(elementChecked).parent().parent().remove();
                        mescroll.triggerDownScroll();
                });
            }
        }
        function failFunction_1(ajax){
        	if (ajax.responseText.indexOf("系统session超时") != -1) {
                 B.alert("提示", "系统session超时,请重新登录", function() {
                     nativePage.executeScript("back()");
                 });
            } else {
                 B.alert("提示", "提交失败");
            }
        }
        function changePJStat(){
        	baseAjax({
	        		pattern:'http://changePJStat',
	        		data:{flowid:userData.flowid,wfid:userData.flowInsId,stepcode:userData.stepcode,projectid:userData.objectid,stepid:userData.stepid},
	        		isBlock:true,
	        		success:'successFunction_A1',
	        		error:''
	        });
        }
        function successFunction_A1(ajax){
        	if (ajax.responseText.indexOf("系统session超时") != -1) {
                B.alert("提示", "系统session超时,请重新登录", function() {
                     nativePage.executeScript("back()");
                });
            } else {
                B.alert("提示", "操作成功", function() {
	                $(elementChecked).parent().parent().remove();
                    mescroll.triggerDownScroll();
	            });
            }
        }
        function getBXFZ(){
        	baseAjax({
	        		pattern:'http://searchFlowSomeInfo',
	        		data:{method:"getStepID",wfid:userData.flowInsId,wfstepid:userData.stepInsId},
	        		isBlock:true,
	        		success:'successFunction_A2',
	        		error:''
	        });
        }
        function successFunction_A2(ajax){
        	var data = eval('('+ajax.responseText+')');
        	if(data.success){
        	   var stepObj = data.data;
               if(stepObj.length>0){
                  dataObj.stepid = stepObj[0].stepid;
                  dataObj.stepexpid = stepObj[0].wfstepid;
                  baseAjax({
                  	pattern:'http://saveCfgFormAction',
	        		data:dataObj,
	        		isBlock:true,
	        		success:'successFunction_A3',
	        		error:''
                  });       
               }
        	}
        }
        function successFunction_A3(ajax){
        	B.alert("提示", "操作成功", function() {
	             $(elementChecked).parent().parent().remove();
                 mescroll.triggerDownScroll();
	        });
        }
        function savesfddzy(m_sfddzykf,m_sfddzycs,m_sfddzyyw){
            var itemid=userData.objectid;
            var stepcode = userData.stepcode;
            baseAjax({
        		pattern:'http://savesfddzy',
        		data:{'sfddzykf':m_sfddzykf,
        			'sfddzycs':m_sfddzycs,
        			'sfddzyyw':m_sfddzyyw,
        			'itemid':itemid,
        			'stepcode':stepcode
        		},
        		isBlock:false,
        		success:'successFunction_2',
        		error:''
        	});
        };
        function successFunction_2(ajax){
        	
        }
        function syncFlowBack(){
            //先获取除当前步骤的其他分支
            baseAjax({
        		pattern:'http://searchFlowSomeInfo',
        		data:{method:'getWfstepid',wfid:userData.flowInsId,wfstepid:userData.stepInsId},
        		isBlock:true,
        		success:'successFunction_3',
        		error:''
        	});
        }
        var stepObj;
        function successFunction_3(ajax){
        	var obj = eval('('+ajax.responseText+')');
        	if(obj.success){
        	   stepObj = obj.data;
               if(stepObj.length>0){
                  dataObj.stepid = stepObj[0].stepid;
                  dataObj.stepexpid = stepObj[0].wfstepid;
                  baseAjax({
                  	pattern:'http://saveCfgFormAction',
	        		data:dataObj,
	        		isBlock:true,
	        		success:'successFunction_4',
	        		error:''
                  });       
               }
               //setTimeout(function(){
	           //    B.alert("提示", "操作成功", function() {
	           //         $(elementChecked).parent().parent().remove();
	           //         mescroll.triggerDownScroll();
	           //    });
               //},3500);
            }
        }
        function successFunction_4(ajax){
        	baseAjax({
                  	pattern:'http://setwf.jsp',
	        		data:dataObj,
	        		isBlock:true,
	        		success:'successFunction_5',
	        		error:''
            }); 
        }
        function successFunction_5(ajax){
        	if(stepObj.length>1){
                  dataObj.stepid = stepObj[1].stepid;
                  dataObj.stepexpid = stepObj[1].wfstepid;
                  baseAjax({
                  	pattern:'http://saveCfgFormAction',
	        		data:dataObj,
	        		isBlock:true,
	        		success:'successFunction_6',
	        		error:''
                  });       
             }
        }
        function successFunction_6(ajax){
        	baseAjax({
                  	pattern:'http://setwf.jsp',
	        		data:dataObj,
	        		isBlock:true,
	        		success:'successFunction_7',
	        		error:''
            }); 
        }
        function successFunction_7(ajax){
        	B.alert("提示", "操作成功", function() {
	               $(elementChecked).parent().parent().remove();
	           	   mescroll.triggerDownScroll();
	        });
        }

//  页面加载完成之后的功能
$(document).ready(function () {
    $(".select-clear").hide();
    $(".select-clear").click(function () {
        $(".select-result dl .selected").remove();
        $(".select-clear").remove();
    })
    $("a[name='canChecked']").click(function() {
        $(this).toggleClass("require");
    });
    $(".select_root a").click(function () {
        $(this).addClass('contarier').siblings().removeClass('contarier');
    });
});

// 弹出框重置功能
$('.determine').click(function () {
    $('.select_root a').removeClass('contarier');
    $('#select1 dd a').removeClass('require')
});

// 弹出框里确定按钮执行的方法
$('.replacement').click(function () {
    var filterId = $('.contarier').attr('name');
    var objecttypes = "";
    $('.require').each(function(){
        if(objecttypes.length!=0){
            objecttypes += ",";
        }
        objecttypes += $(this).attr("hidID");
    });
    //  隐藏弹出框
    $('#right_overlay_aside').removeClass('active');
    $('#section_container_mask').css({
        'display': 'none'
    });
    $('.sech_ipt').val('');
    baseAjax({
    	pattern:"http://searchFlowList",
    	method:"post",
    	data:{filterId:filterId,objecttypes:objecttypes},
    	isBlock:true,
    	success:"successFunction4",
    	error:"failFunction4"
    });
});
function successFunction4(ajax){
	var data = eval("("+ajax.responseText+")");
	$('.pend_list ul li').remove();
    var search = data.listData;
    $('.sech_icn').get(0).onclick=function () {
	       $('.pend_list ul').empty().not($(this));
	       listData(search);
	};
    if (search.length == 0) {
       $('.pend_list ul').append(
          '<li class="pend_shuju">没有搜索到数据</li>'
       )
       return false;
    }
    listData(search); 
}		  
function failFunction4(ajax){}
function successFunction_8(ajax){}
function successFunction_9(ajax){}
function successFunction_10(ajax){}

