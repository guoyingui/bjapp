$('#annot_fj').click(function() {
	$(this).hide();
	return false;
});
$('.annot_big').click(function() {
	return false;
});
$('.annot_qx').click(function() {
	$('#annot_fj').hide();
});
$('.annot_ck').click(function() {
	$('#annot_fj').css('display', 'block')
});

 // 列表点击收缩
$(".row2-left").click(function() {
	 $(this).next().slideToggle();
	 $(this).find('i').toggleClass('icon-arrowdown');
	 $(this).find('i').toggleClass('icon-arrowright');
});

$('.superinduce').click(function() {
	$('.list_ggclr').css('display', 'block')
	superinduce();
})
function superinduce(){
	baseAjax({
		pattern : 'http://getDepUser',
		data : {},
		isBlock : true,
		success : 'successFunction2',
		error : 'failFunction2'
	});
}
var jsparam = 0;
//计数
function successFunction2(ajax) {
	var data = eval("(" + ajax.responseText + ")");
	$("#list_ryxs_table").empty().not($(this));
	$('.list_ss').val("");
	var users = data.userlist;
	for (var i = 0; i < users.length; i++) {
		var user = users[i];
		if (user.userjp == undefined) {
			$("#pinyin").val(user.username);
			user.userjp = $("#pinyin").toPinyin().toLowerCase();
		}
		if (user.username.indexOf('administrator') > -1 || user.username.indexOf('user') > -1 || user.username.indexOf('安全可控') > -1) {
			continue;
		}
		var data = '<tr><td><input name="departmentname" type="checkbox" value="' + user.username + '"/>' + '</td><td>' + user.username + '</td><td>' + user.departmentname + '</td></tr>';
		$('#list_ryxs_table').append(data);
	};
	var checkboxValue = new Array();
	checkboxValue.push(users);
	$('.list_ss').get(0).onkeydown = function() {
		jsparam++;
	}
	$('.list_djss').get(0).onclick = function() {
		$("#list_ryxs_table").empty().not($(this));
		usersData(checkboxValue);
	};
	$('.list_ss').get(0).onkeyup = function() {
		$('.list_djss').get(0).onclick();
		return;
	}
}

function failFunction2(ajax) {
	B.alert('提示', '请求失败');
}

function usersData(checkboxValue) {
	var jsparamTemp = jsparam;
	for (var k = 0; k < checkboxValue[0].length; k++) {
		if (jsparam > jsparamTemp) {
			return;
		}
		var SearchBox_adv = checkboxValue[0][k];
		var searchText = $('.list_ss').val();
		if (searchText != "" && SearchBox_adv.username.indexOf(searchText) == -1 && SearchBox_adv.userjp.indexOf(searchText.toLowerCase()) != 0) {
			continue;
		}
		if (SearchBox_adv.username.indexOf('administrator') > -1 || SearchBox_adv.username.indexOf('user') > -1 || SearchBox_adv.username.indexOf('安全可控') > -1) {
			continue;
		}
		var sech_icn2 = '<tr><td><input name="departmentname" type="checkbox" value="' + SearchBox_adv.username + '"/>' + '</td><td>' + SearchBox_adv.username + '</td><td>' + SearchBox_adv.departmentname + '</td></tr>'
		$('#list_ryxs_table').append(sech_icn2)
	}
}

$('.list_qx').click(function() {
	$('.list_ggclr').css('display', 'none');
})

$('.list_qdtj .list_qd').click(function() {
	$("input[name=departmentname]:checked").each(function(){
		var app = $(this).attr('value');
		var arr = '<tr><td><input type="checkbox" name="item"></td><td>' + app +'</td><td>111</td><td>222</td></tr>'
		$('#listTable').append(arr);
	});
	$('.list_ggclr').css('display', 'none');
});
$('.intbdb_delete').click(function(){
	var olistTable = document.getElementById('listTable');
	var items = document.getElementsByName("item")
	for(var m=0; m < items.length; m++){
		if(items[m].checked){			
			var oParentnode = items[m].parentNode.parentNode;
			olistTable.removeChild(oParentnode);
			m--;
		}
	}
})

