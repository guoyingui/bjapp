/**
 * 自定义弹出框
 *
 */
var dialog = new Dialog("#pop_custom", {
    onClick: function (s) {
        console.log(s.target);
        if (s.target.text == "取消") {
            s.hide();
        } else if (s.target.text == "确定") {
            console.log("确定");
        }
    }
});

//middle
$("#middle").click(function () {
    dialog.setPos("middle");
    dialog.show();
});
var tabbar = document.getElementById("tabbar");
var tab = tabbar.querySelectorAll(".tab");
var carouselPage;

//初始化滑动容器
function initSlider() {
    carouselPage = new Slider("#carouselPage", {
        "onSlideChangeEnd": function (e) {
            tabActive(e.index);
        }
    });
}

//选中tab
function tabActive(index) {
    for (var i = 0,
            t; t = tab[i++];) {
        t.classList.remove("active");
    }
    tab[index].classList.add("active");
}

//绑定tab点击事件
function tabBindClick() {
    for (var i = 0,
            t; t = tab[i++];) {
        (function (i) {
            t.addEventListener("click", function () {
                carouselPage.slideTo(i - 1);
                tabActive(i - 1);
            }, false);
        })(i);
    }
}

window.addEventListener("load", function () {
    initSlider();
    tabBindClick();
    var f = new Form('#carouselPage');
    var a = new Alert();
    var date = new Date;
    console.log(date)
    window.submit = function () {
        var isOk = f.validate();
        if (isOk) {
            var args = f.serialize();
            // a.setText("你所要提交的参数是：" + args);
            // a.show();
            $.ajax({
                url: 'http://api.money.126.net/data/feed/0000001,1399001?callback=refreshPrice',
                type: 'post',
                data: args
            })
        }
    }
}, false);

//定义exmobi返回
function back() {
    history.go(-1);
}


$(".form-row ul li span").click(function () {
    $(this).next().slideToggle();
    $(this).find('i').toggleClass('icon-arrowright');
})

$(function () {
    $.ajax({
        type: 'POST',
        url: 'json_list.json',
        dataType: 'json',
        success: function (data) {
            // console.log(data.listData)
            var msg = data.listData;
            console.log(msg[0].user);
            $('#numbering').val(msg[0].user)
            // $.each(msg, function (index,values) {
            //     // console.log(values)
            //     // var item = values.objectname
            //     // console.log(item)
            //     // // debugger
            //     // $('#numbering').val(item)
            //     $.each(values, function (index2, value) {
            //         console.log(value)
            //         console.log(index2)
            //         alert(value.objectname + ' ' + value.user)
            //     })
            // })
            // for(var i = 0; i < msg.lenght; i++){
            //     item = msg[i]
            //     debugger
            //     console.info(item['user'],item['stepname'])
            // }
        },
        error: function () {
            alert("系统出现问题");
        }
    })
})