/*
*	ExMobi4.x+ JS
*	Version	: 1.0.0
*	Author	: Administrator
*	Email	:
*	Weibo	:
*	Copyright 2016 (c)
*/

// 点击取消按钮
$('#quxiao').click(function () {
	$('.annot_fsxx').css('display', 'none');
});
//点击发送消息按钮
$('#sending').click(function() {
	$('.annot_fsxx').css('display', 'block')
})
// 点击确定按钮
$('#queding').click(function () {
	var userid = document.getElementById('userid1').value;
	var title = document.getElementById('title').value;
	var content = document.getElementById('content').value;
	if(userid==""){
		B.alert("提示", "请选择收信人");
 		return;
    }
	baseAjax({
		pattern : 'http://sendMsgAction',
		data:{'userid':userid,
		'title':title,
		'content':content},
		isBlock : true,
		success : 'successSendMsgAction',
		error : ''
	});
})

function successSendMsgAction(ajax){
	$('.annot_fsxx').css('display', 'none');
}

$('.list_qx1').click(function() {
	$('.list_ggclr1').css('display', 'none');
})

//用户选择
function userName1(){
	$('#list_ggclr1').show();
	baseAjax({
		pattern : 'http://getDepUser',
		data : {},
		isBlock : true,
		success : 'successUserName1',
		error : 'failUserName1'
	});
}

var jsparam1 = 0;
//计数
function successUserName1(ajax) {
	var data = eval("(" + ajax.responseText + ")");
	$("#list_ryxs_table1").empty().not($(this));
	$('.list_ss1').val("");
	var users = data.userlist;
	for (var i = 0; i < users.length; i++) {
		var user = users[i];
		if (user.userjp == undefined) {
			$("#pinyin").val(user.username);
			user.userjp = $("#pinyin").toPinyin().toLowerCase();
		}
		if(user.username.indexOf('administrator') > -1 || user.username.indexOf('user') > -1 || user.username.indexOf('安全可控') > -1){
        	continue;
        }
		var data = '<tr><td><input name="departmentname" type="checkbox" hidID="' + user.username + '" value="' + user.userid + '"/>' + '</td><td>' + user.username + '</td><td>' + user.departmentname + '</td></tr>';
		$('#list_ryxs_table1').append(data);
	};
	var checkboxValue = new Array();
	checkboxValue.push(users);
	$('input[name="departmentname"]').click(function() {
		var val = $(this).attr("value");
		$('input[name="departmentname"]:checked').each(function() {
			if (val != $(this).attr("value")) {
				$(this).attr('checked', false)
			} else {
				$(this).attr('checked', true)
			}
		})
	})

	$('.list_ss1').get(0).onkeydown = function() {
		jsparam1++;
	}
	$('.list_djss1').get(0).onclick = function() {
		$("#list_ryxs_table1").empty().not($(this));
		usersData1(checkboxValue);
	};
	$('.list_ss1').get(0).onkeyup = function() {
		$('.list_djss1').get(0).onclick();
		return;
	}
}

function failUserName1(ajax) {
	B.alert('提示', '请求失败');
}

function usersData1(checkboxValue) {
	var jsparamTemp = jsparam;
	for (var k = 0; k < checkboxValue[0].length; k++) {
		if (jsparam > jsparamTemp) {
			return;
		}
		var SearchBox_adv = checkboxValue[0][k];
		var searchText = $('.list_ss1').val();
		if (searchText != "" && SearchBox_adv.username.indexOf(searchText) == -1 && SearchBox_adv.userjp.indexOf(searchText.toLowerCase()) != 0) {
			continue;
		}
		if(SearchBox_adv.username.indexOf('administrator') > -1 || SearchBox_adv.username.indexOf('user') > -1 || SearchBox_adv.username.indexOf('安全可控') > -1){
        	continue;
        }
		var sech_icn2 = '<tr><td><input name="departmentname" type="checkbox" hidID="' + SearchBox_adv.username + '" value="' + SearchBox_adv.userid + '"/>' + '</td><td>' + SearchBox_adv.username + '</td><td>' + SearchBox_adv.departmentname + '</td></tr>'
		$('#list_ryxs_table1').append(sech_icn2)
	}
	$('input[name="departmentname"]').click(function() {
		var val = $(this).attr("value");
		$('input[name="departmentname"]:checked').each(function() {
			if (val != $(this).attr("value")) {
				$(this).attr('checked', false)
			} else {
				$(this).attr('checked', true)
			}
		})
	})
}
$('.list_qd1').click(function () {
	var obj = $("input[name=departmentname]:checked");
	var id = obj.val();
	var name = obj.attr("hidID");
    if(id == undefined){
    	B.alert('提示', '请选择处理人'); 
    	return;
    }
    $('#userid1').val(id);
    $('#username1').val(name);
    $('.list_ggclr1').css('display', 'none');
})


