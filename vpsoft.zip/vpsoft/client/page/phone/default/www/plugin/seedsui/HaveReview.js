/*
*	ExMobi4.x+ JS
*	Version	: 1.0.0
*	Author	: huanhuan8023
*	Email	:
*	Weibo	:
*	Copyright 2016 (c)
*/

// mescroll 下拉刷新
var mescroll;
document.addEventListener("plusready", function() {
	mescroll = new MeScroll("mescroll", {//第一个参数"mescroll"对应上面布局结构div的id
		down : {
			callback : downCallback
		},
		up : {
			use: false
		}
	});
}, false);
// 下拉刷新
function downCallback() {
	var status = 1;
	baseAjax({
		pattern : "http://wokFlowHandle",
		method : "post",
		data : {
			status : status
		},
		isBlock : true,
		success : "successFunction",
		error : "failFunction"
	}); 
}
var jsparam = 0;//计数
function successFunction(ajax) {
	var data = eval("(" + ajax.responseText + ")");
	mescroll.endSuccess();
	$('.pend_list ul').empty().not($(this));
	//$('.pend_list ul a').remove();
	/*if (data.listData.length == 0) {
		$('.pend_list ul').append('<li class="pend_shuju">没有搜索到数据</li>')
		return false;
	}*/
	var reviewList = data.listData;
	genList(reviewList);
	//待处理查找功能
    $('.sech_ipt2').get(0).onkeydown=function(){
         jsparam++;
    };
    $('.sech_icn').get(0).onclick=function () {
         $('.pend_list ul').empty().not($(this));
         genList(reviewList);;
    };
    $('.sech_ipt2').get(0).onkeyup=function(){
         $('.sech_icn').get(0).onclick();
         return;
    };
}

function failFunction(ajax) {
	//联网失败的回调,隐藏下拉刷新和上拉加载的状态
	mescroll.endErr();
}

function genList(data) {
    var jsparamTemp = jsparam;
    var searchText = $('.sech_ipt2').val();
	for (var index = 0; index < data.length; index++) {
	    if(jsparam>jsparamTemp){
             return;
        }
		var element = data[index];
		if(element.reviewnamepy==undefined){
             $("#pinyin").val(element.reviewname);
             element.reviewnamepy=$("#pinyin").toPinyin().toLowerCase();
        }
        if (searchText != "" && element.reviewname.indexOf(searchText) == -1&&element.reviewnamepy.indexOf(searchText.toLowerCase()) != 0) {
             continue;
        }
		var stepid = element.stepid;
		var flowid = element.flowid;
		var objectid = element.objectid;
		var objecttype = element.objecttype;
		var reviewperid = element.reviewperid;
		$('.pend_list ul').append('<a href="HasAssessed.html" class="popup_parallel" onclick="parallel(' + stepid + ',' + flowid + ',' + objectid + ',' + objecttype + ',' + reviewperid + ')"><li><div class="pend_mide">' + '<figure class="pd_icnl"></figure>' + '<hgroup><h4 class="whohas">' + element.reviewname + '</h4><p class="hgroup">评审类型:'+ element.stepname +'</p>' + '<p><span class="element">主持人:' + element.annotateusername + '</span><time>' + element.enddate + '</time></p></hgroup>' + '</li></a>')
	}
	if($('.pend_list ul a').length==0){
	    $('.pend_list ul').append('<li class="pend_shuju">没有搜索到数据</li>');
	}
}

function parallel(stepid, flowid, objectid, objecttype, reviewperid) {
	var userData = {
		stepid : stepid,
		flowid : flowid,
		objectid : objectid,
		objecttype : objecttype,
		reviewperid : reviewperid
	};
	// 页面之间传值
	var user = JSON.stringify(userData)
	$('.popup_parallel').attr("href", "HasAssessed.html?data=" + user)
}

