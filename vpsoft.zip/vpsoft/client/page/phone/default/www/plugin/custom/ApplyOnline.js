/*
*	ExMobi4.x+ JS
*	Version	: 1.0.0
*	Author	: luoyi
*	Email	: 
*	Weibo	: 
*	Copyright 2016 (c) 
*/

		var flowid, flowexpid, stepid, stepexpid, objectID;
		var objecttype, formtype, formid, fid, steptype, stepcode;
		var userid, username;
		stepcode = user.stepcode;
		var nowDate = new Date();
		var sysdate = nowDate.getFullYear() + "-" + (nowDate.getMonth() + 1) + "-" + nowDate.getDate();
		var nextstepid = "";
		var nextstepidh = "";
		var nextstepid2 = "";
		var nextstepid3 = "";
		var ycbzbh = "";
		var stepUserSelect;
		//查询输入计数
		var jsparam=0;
		
		//上线申请所需项目信息
		var isStart=true;
		var isSxian=true;
		var rs1;
		// 获得流程下一步的流程步骤id
		var res1;
		var nextstepid1;
		var ywzzarray=new Array();
		
		//左滑右滑
		$("body").on("touchstart", function(e) {
			e.preventDefault();
			startX = e.originalEvent.changedTouches[0].pageX,
			startY = e.originalEvent.changedTouches[0].pageY;
		});
		$("body").on("touchmove", function(e) {
			e.preventDefault(); 
			moveEndX = e.originalEvent.changedTouches[0].pageX,
			moveEndY = e.originalEvent.changedTouches[0].pageY,
			X = moveEndX - startX,
			Y = moveEndY - startY;
			//从左向右滑
			if ( Math.abs(X) > Math.abs(Y) && X < -35 ) {
				tabs[1].onclick();
			}else if ( Math.abs(X) > Math.abs(Y) && X > 35 ) {//从右向左滑
				tabs[0].onclick();
			}
		});
		$(function(){
			layer.open({
				type: 2
			});
			if(user){
				if (user.steptype == 8) { //处理步骤
					$("#tjButton").show();
					$("#spButton").hide();
				} else if (user.steptype == 4) { //审批步骤
					$("#tjButton").hide();
					$("#spButton").show();
				}
				hideField();
			}
		});
		function hideField(){
			var objecttype = user.objecttype;
        	var stepcode = user.stepcode;
        	if (objecttype == "2591") {
        		if(stepcode=="15" || stepcode=="09" || stepcode=="10" || stepcode=="16" || stepcode=="18"){
					$("#middle").show();
					$("#middle").prev().get(0).style.paddingRight="0px";
					
					if(stepcode=="18"){
						//$("#sending").show();
						//$("#sending").prev().get(0).style.paddingRight="0px";
					}
				}else if(stepcode=="22"){
					//$("#sending").show();
					//$("#sending").prev().get(0).style.paddingRight="0px";
				}else{
					$("#middle").prev().get(0).style.paddingRight="80px";
				}
        	}
		}
		//加载完毕后触发plusready事件
		document.addEventListener("plusready",function(){
			//这里可以调用ExMobi提供的jsapi
			//请求流程数据
			try {
				getInfomation(user);
			} catch (e) {

			}
		},false);
		
		/*Ajax获取数据绑定到页面对应元素*/
		function getInfomation(user) {
			baseAjax({
				pattern:'http://getyyzzve',
				data:{},
				isBlock:true,
				success:'successGetyyzzve',
				error:''
			});
			baseAjax({
				pattern:'http://getFlowInfo',
				data:user,
				isBlock:false,
				success:'successFunctionH',
				error:'failFunctionH'
			});
		} 
		/*ajax成功回调方法*/
		function successFunctionH(ajax){
			if (ajax.responseText.indexOf("系统session超时") != -1) {
				 B.alert("提示", "系统session超时,请重新登录", function() {
					   nativePage.executeScript("back()");
				 });
			}else{
				var objData = eval("("+ajax.responseText+")");
				if (objData != null) {
					//console.log(objData);
					flowid = objData.flowid;
					flowexpid = objData.flowexpid;
					stepid = objData.stepid;
					stepexpid = objData.stepexpid;
					objectID = objData.objectid;
					objecttype = objData.objecttype;
					formtype = objData.formtype;
					formid = objData.formid;
					fid = objData.fid;
					steptype = objData.steptype;
					userid = objData.userid;
					username = objData.username;
					stepUserSelect = objData.stepUserSelect;
					//获取节点对象数组
					var groups = objData.workItemlist;
					for (var i = 0; i < groups.length; i++) {
						var Defaultwrap = groups[i].Defaultwrap; //节点是否默认展开
						var Sequencekey = parseInt(groups[i].Sequencekey) - 1; //节点在表单中顺序
						if ($("#group_id_" + Sequencekey).get(0) != undefined && Defaultwrap == 1 && Sequencekey !=
							1) { //节点在页面存在并默认展开时
							var group_id_1 = $("#group_id_1");
							var group_id_new = $("#group_id_" + Sequencekey);
							group_id_new.children(":first").children(":first").css('display','inline-block');
							$("#group_id_" + Sequencekey).remove();
							group_id_new.replaceAll("#group_id_1");
							$("#groupInfo").children(":first").before(group_id_1);
							group_id_1.children(":first").children(":first").css('display','none');
						}
						//节点对象下字段数组
						var fieldlist = groups[i].fieldlist;
						for (var j = 0; j < fieldlist.length; j++) {
							var field = fieldlist[j];
							setFieldInfo(field);//设置字段属性
						}
					}
					getStepUserList();//获取步骤处理人
					
					if (stepcode == 18 || stepcode == 22) { //审批步骤
						//$("#noteid").css('display','block');
					}
					if (stepcode == 14) { //审批步骤
						//$("#m_wcshjsxid").css('display','block');
					}
					if (stepcode == 15) { //审批步骤
						document.getElementById('m_sffhyw1').value=1;
					}
				}
				// 列表点击收缩
				$(".group").click(function() {
					$(this).next().slideToggle();
					$(this).find('i').toggleClass('icon-arrowdown');
					$(this).find('i').toggleClass('icon-arrowright');
					// $(this).parent().siblings().children('ul').removeClass('hover').slideUp();
				});
				$("#ListElementHead").children(":first").next().children(":first").click();
				}
				layer.closeAll();
		}	
		/*ajax失败回调方法*/	  
		function failFunctionH(ajax){
			if (ajax.responseText.indexOf("系统session超时") != -1) {
				 B.alert("提示", "系统session超时,请重新登录", function() {
					   nativePage.executeScript("back()");
				 });
			} else {
				 B.alert("提示", "请求数据失败");
			} 
		}  
		
		/*定义一个数组，记录需要页面所有的字段*/
		var checkFieldList = new Array();
		var list = [];
		/*设置字段属性*/
		function setFieldInfo(field) {
			var obj = $("#" + field.filedname);
			if (obj.get(0) != undefined) {
				checkFieldList.push(field.filedname);
				obj.val(field.value);
				obj.attr("hidID", field.hidvalue);
				obj.attr("propertyText", field.title);
				obj.attr("propertyType", field.datatype);
				obj.attr("mustInput", field.inputtype);
				if(field.filedname=="m_xqfh6"){
					//alert(field.inputtype+"--"+field.value+"--"+field.datatype);
				}
				if (field.inputtype == 0) {
					obj.attr("disabled", true);
					if (obj.get(0).tagName == "SELECT") {
						obj.addClass("inputRead");
					} else {
						obj.attr("class", "inputRead");
					}
				} else if (field.inputtype == 2) {
					if (obj.get(0).tagName == "TEXTAREA") {
						//obj.attr("class", "textareaWrite");
						obj.prev().append('<span class="lableMust"></span>');
					} else if (obj.get(0).tagName == "SELECT") {
						//obj.addClass("inputWrite");
						obj.parent().prev().append('<span class="lableMust"></span>');
					} else {
						//obj.attr("class", "inputWrite");
						obj.prev().append('<span class="lableMust"></span>');
					}
					if(field.datatype==91){
						obj.attr("readonly",true);
						obj.get(0).onclick=function(){searchUser(field.filedname,false);return;};
						obj.next().get(0).onclick=function(){searchUser(field.filedname,false);return;};
					}
				} else if (field.inputtype == 1) {
					if (obj.get(0).tagName == "TEXTAREA") {
						obj.attr("class", "textareaNomal");
					} else if (obj.get(0).tagName == "SELECT") {
						//obj.addClass("inputNomal");
					} else {
						//obj.attr("class", "inputNomal");
					}
					if(field.datatype==91){
						obj.attr("readonly",true);
						obj.get(0).onclick=function(){searchUser(field.filedname,false);return;};
						obj.next().get(0).onclick=function(){searchUser(field.filedname,false);return;};
					}
				}
				obj.attr("systype", field.systype);
			} else {
				var fieldInfo = new Object();
				fieldInfo.fieldID = field.filedname; //属性id
				fieldInfo.fieldText = field.title; //显示名称
				fieldInfo.fieldType = field.datatype; //属性类型
				fieldInfo.fieldValue = field.value; //值
				var typeStr = "," + field.datatype + ",";
				if (',0,1,2,4,8,11,81,82,83,85,91,92,93,94,95,97,98,999,995,'.indexOf(typeStr) >= 0) {
					if (',91,92,93,94,97,98,81,82,83,999,'.indexOf(typeStr) >= 0) {
						fieldInfo.fieldValue = field.hidvalue;
					} else {
						fieldInfo.fieldValue = field.value || "";
					}
				}
				fieldInfo.systype = field.systype; //是否系统属性
				list.push(fieldInfo);
				//流程附件单独处理
				if(field.filedname=="m_fj"){
					for(var i=0;i<field.filelist.length;i++){
						var filename = field.filelist[i].fileName+'.'+field.filelist[i].fileType;
						var filesize = field.filelist[i].fileSize;
						var fileid = field.filelist[i].fileID;
						var filepath = field.filelist[i].filePath;
						var str = '<div class="tab_big">'+
										'<span class="tab_spans" style="font-size:18px;" id="file_'+field.filelist[i].fileID+'">'+filename+'</br><span style="height:20px;width:100%;color:#408BCA;font-size:14px;">'+ filesize +'</span></span>'+
										//'<span class="tab_cha">'+
											//'<a id="file_'+field.filelist[i].fileID+'">查看</a>'+
										//'</span>'+
									'</div>';
						$("#fileList").append(str);
						eval('var fn=function(){downFile('+fileid+');return;}');
						$("#file_"+field.filelist[i].fileID).get(0).onclick=fn;
					}
				}
			}
		}
		
		/*获取步骤以及步骤处理人*/
		function getStepUserList() {
			var dataObj = new Object();
			dataObj.flowid = flowid;
			dataObj.flowexpid = flowexpid;
			dataObj.stepid = stepid;
			dataObj.stepexpid = stepexpid;
			dataObj.objectid = objectID;
			dataObj.objecttype = objecttype;
			dataObj.formtype = formtype;
			dataObj.formid = formid;
			dataObj.fid = fid;
			//自动带出项目经理
			ajaxGetXmInfo2();
			baseAjax({
				pattern:'http://getStepUserList',
				data:dataObj,
				isBlock:false,
				success:'successFunctionI',
				error:'failFunctionI'
			});
		}
		
		function successFunctionI(ajax){
					var res = eval("("+ajax.responseText+")");
					//后续步骤处理人
					if (res.success == false) {
						$("#steplist_section").hide();
					} else {
						$("#steplist_section").show();
						//alert(JSON.stringify(res.root2));
						//上线申请
						if (objecttype == "2591") {
							var root2 = res.root2;
							if(stepcode=="15"){
								var ysywzz=new Object();
								ysywzz.abailableuser=ywzzarray;
								ysywzz.stepid="527";
								ysywzz.stepcode="16";
								ysywzz.stepname="预设运维部组长";
								ysywzz.fixflag=0;
								ysywzz.stepsel=true;
								ysywzz.usermode=2;
								ysywzz.usermodestr="抢占";
								ysywzz.initusertype=4;
								ysywzz.steptype="审批";
								ysywzz.mustinput=0;
								ysywzz.userid="";
								ysywzz.username="";
								root2.push(ysywzz);
								genStepUserGrid(root2);
								//自动带出项目经理
								ajaxGetXmInfo2();
								getNextStepId(flowid,'11');
								yckf();//隐藏多余步骤
								dckfbld();//带出之前设置过的开发部领导
								dcywbzz();//带出设置过的运维组长
							}else if (stepcode == "11") {
								genStepUserGrid(root2);
								//自动带出开发负责人
								//隐藏多余步骤
								yckf();
								ajaxGetXmInfo2();
								getNextStepId(flowid,'12');
							}else if (stepcode == "09") {
								genStepUserGrid(root2);
								ywxldsp();
								dckfbld();
								dcywbzz();
								var obj = document.getElementById("19_user_tr");
								if(obj) obj.style.display="none";
							}else if (stepcode == "10") {
								genStepUserGrid(root2);
								getNextStepId(flowid,'19');
								getYcbzbh("11");
								var obj = document.getElementById("09_user_tr");
								if(obj) obj.style.display="none";
							}else if(stepcode=="14"){
								genStepUserGrid(root2);
								//自动带出运营代表
								kfbldsp();
								yckf();
								var xmlbObj = document.getElementById('m_xmsslb');
								if(xmlbObj.value==1){
									ajaxGetXmInfo2();
									getNextStepId(flowid,'18');
								}
							}else if(stepcode=="16"){
								genStepUserGrid(root2);
								yckf();
							}else if(stepcode=="17"){
								genStepUserGrid(root2);
								ajaxGetWfyydb(flowid,flowexpid,'15');
								getNextStepId(flowid,'18');
								yckf();
							}else if(stepcode=="18"){
								genStepUserGrid(root2);
							}else if(stepcode=="22"){
								genStepUserGrid(root2);
								ajaxGetXmInfo2();
								getNextStepId(flowid,'23');
							}
						} else {
							genStepUserGrid(res.root2);
						}
					}
		}
		
		function failFunctionI(ajax){
			if (e.responseText.indexOf("系统session超时") != -1) {
				   B.alert("提示", "系统session超时,请重新登录", function() {
						nativePage.executeScript("back()");
				   });
			} else {
				   B.alert("提示", "请求数据失败");
			}
		}
		/*构造预设处理步骤和预设处理人*/
		function genStepUserGrid(stepArr) {
			$('tr[name="stepuserList"]').remove();
			for (var i = 0; i < stepArr.length; i++) {
				if(objecttype==2591&&(stepcode=="09")){
					if(4==stepArr[i].initusertype){
						var userArr = stepArr[i].abailableuser; 
						stepArr[i].abailableuser = []; // 把流程用户组置空
						var resArr = stepArr[i].abailableuser;
						for(var j=0;j<userArr.length;j++){
							for(var k=0;k<stepUserSelect.length;k++){
								if(userArr[j].userid==stepUserSelect[k].userid){
									resArr.push({userid:userArr[j].userid,username:userArr[j].username,departmentname:userArr[j].departmentname});
								}
							}
						}
						if(resArr.length==1){
							stepArr[i].userid = resArr[0].userid;
							stepArr[i].username = resArr[0].username;
						}
					}
				}
				var stepStr = '<tr name="stepuserList" id="' + stepArr[i].stepcode +
					'_user_tr"><td class="input-group-lg">' + stepArr[i].stepname + '</td>' +
					'<td></td>' +
					'<td>' +
					'   <input class="input-item" id="step_' + stepArr[i].stepid +
					'_user" type="text" readOnly usermode="' + stepArr[i].usermode + '" stepid="' + stepArr[i].stepid +
					'" mustinput="' + stepArr[i].mustinput + '" hidID="' + stepArr[i].userid + '" value="' + stepArr[i]
					.username + '">' +
					'   <span id="step_' + stepArr[i].stepid + '_span">' +
					'	   <img src="assets/app/img/icon_33.png">' +
					'   </span>' +
					'</td></tr>';
				$("#stepuserListTable").append(stepStr);
				if (stepArr[i].initusertype == 0) { //
					eval('var fn=function(){getUserData(stepArr[' + i + '].stepid,0,20501);return;}');
				} else {
					eval('var fn=function(){showStepUser(stepArr[' + i + '].stepid,stepArr[' + i + '].abailableuser,1);return;}');
				}
				$("#step_" + stepArr[i].stepid + "_span").get(0).onclick = fn;
				$("#step_" + stepArr[i].stepid + "_user").get(0).onclick = fn;
			}
		}
		var searchTextOld = "";
		/*展示预设处理人查询页面*/
		function showStepUser(stepid, abailableuser, type) {
			var searchText = $('#preset_stepuser_span').prev().val();
			if($("#pop_custom1").css("display")!="none"&&$('tr[name="abailableuser_tr"]').length!=0&&searchTextOld==searchText){
				return;
			}else{
				searchTextOld = searchText;
			}
			$('tr[name="abailableuser_tr"]').remove();
			var selectedUser = $("#step_" + stepid + "_user").attr("hidID");
			var jsparamTemp = jsparam;
			for (var i = 0; i < abailableuser.length; i++) {
				if(jsparam>jsparamTemp){
					return;
				}
				var stepuser = abailableuser[i];
				if(stepuser.userjp==undefined){
					$("#pinyin").val(stepuser.username);
					stepuser.userjp=$("#pinyin").toPinyin().toLowerCase();
				}
				var selectedFlag = "";
				if (("," + selectedUser + ",").indexOf("," + stepuser.userid + ",") != -1) {
					selectedFlag = "checked";
				}
				
				if (searchText != "" && stepuser.username.indexOf(searchText) == -1&&stepuser.userjp.indexOf(searchText.toLowerCase()) != 0) {
					continue;
				}
				if(stepuser.username.indexOf('administrator') > -1 || stepuser.username.indexOf('PMOmanager') > -1 || stepuser.username.indexOf('user') > -1 || stepuser.username.indexOf('安全可控') > -1){
					 continue;
				}
				var str = '<tr name="abailableuser_tr"><td>' +
					'	<input name="abailableuser" type="checkbox" hidID="' + stepuser.userid + '" val="' + stepuser.username +
					'" ' + selectedFlag + '>' +
					'</td><td>' + stepuser.username + '</td><td>'+ stepuser.departmentname +'</td></tr>';
				 if(type==2||type==1){
					$("#preset_stepuser_table").append(str);
				}
			}
			$('input[name="abailableuser"]').click(function(){
					var val = $(this).attr("hidID");
					$('input[name="abailableuser"]:checked').each(function(){
						if(val!=$(this).attr("hidID")){
							$(this).attr("checked", false);
						}else{
							$(this).attr("checked", true);
						}
					});
			})
			$('#pop_custom1').show();
			$('#preset_stepuser_span').get(0).onclick = function() {
				if (type != 1) {
					getUserData(stepid, 0, 20501);
				} else {
					showStepUser(stepid, abailableuser, type);
				}
				return;
			};
			$('#preset_stepuser_input').get(0).onkeydown=function(){
				jsparam++;
			}
			$('#preset_stepuser_input').get(0).onkeyup=function(){
				$('#preset_stepuser_span').get(0).onclick();
				return;
			}
			$('#preset_stepuser_ensure').get(0).onclick = function() {
				setStepUser(stepid);
				return
			};
		}
		/*回填选择的预设处理人*/
		function setStepUser(stepid) {
			var user = new Object();
			user.userid = "";
			user.username = "";
			$('input[name="abailableuser"]:checked').each(function() {
				if (user.userid != "") {
					user.userid += ","
				}
				if (user.username != "") {
					user.username += ","
				}
				user.userid += $(this).attr("hidID");
				user.username += $(this).attr("val");
			});
			$("#step_" + stepid + "_user").attr("hidID", user.userid);
			$("#step_" + stepid + "_user").val(user.username);
			$('#pop_custom1').hide();
			return;
		}
		
		var flowUserList = [];
		function getUserData(stepid, roleID, componentID) {
			if(flowUserList.length==0){
				baseAjax({
					pattern:'http://searchUser',
					data:{method:'searchUser',roleID:roleID,componentID:componentID,userName:''},
					isBlock:false,
					success:'successFunctionJ',
					error:'failFunctionJ',
					relydata:{stepid:stepid}
				});
			}else{
				showStepUser(stepid, flowUserList, 2);
			}
		}
		
		function successFunctionJ(ajax){
			var data = eval('('+ajax.responseText+')');
			if (data.success) {
				  flowUserList = data.root;
				  var relydata = JSON.parse(ajax.getStringData("relydata"));
				  showStepUser(relydata.stepid, flowUserList, 2);
			}
		}
		function failFunctionJ(ajax){
			
		}

		function getCfgWfsStepIdXXX(currentcode) {
			baseAjax({
					pattern:'http://getCfgWfsStepId',
					data:{
						'flowid': flowid,
						'stepcode': currentcode
					},
					isBlock:false,
					success:'successFunctionL',
					error:''
			});
		}
		function successFunctionL(ajax){
			nextstepidh = eval("("+ajax.responseText+")");
		}

		function getYcbzbh(ccode) {
			getCfgWfsStepIdXXX(ccode);
			ycbzbh = nextstepidh;
		}

		function getCfgWfsStepId(currentCode) {
			baseAjax({
					pattern:'http://getCfgWfsStepId',
					data:{
						'flowid': flowid,
						'stepcode': currentCode
					},
					isBlock:false,
					success:'successFunctionM',
					error:''
			});
		}
		function successFunctionM(ajax){
			var rs = eval("("+ajax.responseText+")")
			nextstepid = rs;
			nextstepid2 = rs;
			nextstepid3 = rs;
		}
		
		var userList = [];
		function searchUser(fieldname, isMulti) {
			if(userList.length==0){
				baseAjax({
					pattern:'http://searchUser',
					data:{method:'searchUser',roleID:0,componentID:0,userName:''},
					isBlock:true,
					success:'successFunctionP',
					error:'',
					relydata:{fieldname:fieldname,isMulti:isMulti}
				});
			}else{
				genUserGrid('pop_custom2', fieldname, isMulti, userList);
			} 
		}
		function successFunctionP(ajax){
			var data = eval('('+ajax.responseText+')');
			if (data.success) {
				   var relydata = JSON.parse(ajax.getStringData("relydata"));
				   genUserGrid('pop_custom2', relydata.fieldname, relydata.isMulti, data.root); 
				   userList = data.root;
			}
		}
		var searchText_old = "";
		function genUserGrid(gridname, fieldname, isMulti, userArr) {
			var searchText = $('#' + gridname + '_span').prev().val();
			if($("#"+gridname).css("display")!="none"&&$('tr[name="' + gridname + '_tr"]').length!=0&&searchText_old==searchText){
				return;
			}else{
				searchText_old = searchText;
			}
			$('tr[name="' + gridname + '_tr"]').remove();		   
			var selectedUser = $("#" + fieldname).attr("hidID");
			var jsparamTemp = jsparam;
			for (var i = 0; i < userArr.length; i++) {
				if(jsparam>jsparamTemp){
					return;
				}
				var stepuser = userArr[i];
				if(stepuser.userjp==undefined){
					$("#pinyin").val(stepuser.username);
					stepuser.userjp=$("#pinyin").toPinyin().toLowerCase();
				}
				var selectedFlag = "";
				if (("," + selectedUser + ",").indexOf("," + stepuser.userid + ",") != -1) {
					selectedFlag = "checked";
				}
				if (searchText != "" && stepuser.username.indexOf(searchText) == -1&&stepuser.userjp.indexOf(searchText.toLowerCase()) != 0) {
					continue;
				}
				if(stepuser.username.indexOf('administrator') > -1 || stepuser.username.indexOf('PMO') > -1){
					continue;
				}
				if(fieldname == 'm_kffzr'){
					var kffzr = '软件开发部';
					if(stepuser.departmentname.indexOf(kffzr) == -1){
						continue;
					}
				};
				if(fieldname == 'm_csfzr'){
					var kffzr = '软件开发部系统测试室';
					if(stepuser.departmentname.indexOf(kffzr) == -1){
						continue;
					}
				}
				if(fieldname == 'm_yweidb'){
					var kffzr = '系统运营部';
					if(stepuser.departmentname.indexOf(kffzr) == -1){
						continue;
					}
				}
				var str = '<tr name="' + gridname + '_tr"><td>' +
					'	<input name="' + gridname + '_input" type="checkbox" hidID="' + stepuser.userid + '" val="' + stepuser.username +
					'" ' + selectedFlag + '>' +
					'</td><td>' + stepuser.username + '</td><td>'+ stepuser.departmentname +'</td></tr>';
				 $('#'+gridname+'_table').append(str); 
				 
			}
			
			// 开发、运维、测试负责人隐藏
			//if(searchText == ""){
				//$('tr[name="' + gridname + '_tr"]').remove();
			//}
			if(!isMulti){
				$('input[name="'+gridname+'_input"]').click(function(){
					var val = $(this).attr("hidID");
					$('input[name="'+gridname+'_input"]:checked').each(function(){
						if(val!=$(this).attr("hidID")){
							$(this).attr("checked", false);
						}else{
							$(this).attr("checked", true);
						}
					});
				})
			}
			$('#'+gridname).show();
			$('#'+gridname+'_span').get(0).onclick = function() {
				genUserGrid(gridname, fieldname, isMulti, userArr);
				return;
			};
			$('#'+gridname+'_input').get(0).onkeydown=function(){
				jsparam++;
			}
			$('#'+gridname+'_input').get(0).onkeyup=function(){
				$('#'+gridname+'_span').get(0).onclick();
				return;
			}
			$('#'+gridname+'_ensure').get(0).onclick = function() {
				setUserValue(gridname,fieldname);
				return
			};
		}
		function setUserValue(gridname,fieldname){
			var user = new Object();
			user.userid="";
			user.username="";
			$('input[name="'+gridname+'_input"]:checked').each(function(){
				if (user.userid != "") {
					user.userid += ","
				}
				if (user.username != "") {
					user.username += ","
				}
				user.userid += $(this).attr("hidID");
				user.username += $(this).attr("val");		
			});
			$("#"+fieldname).attr("hidID",user.userid);
			$("#"+fieldname).val(user.username);
			$('#'+gridname).hide();
		}
		
		//附件下载
		function downFile(fileid){
			baseAjax({
					pattern:'http://getFilePath',
					data:{method:'checkfile',fileid:fileid},
					isBlock:true,
					success:'successFunctionQ',
					error:'',
					relydata:{fileid:fileid}
			}); 
		}
		function successFunctionQ(ajax){
			var res = eval("("+ajax.responseText+")");
			var relydata = JSON.parse(ajax.getStringData("relydata"));
			if(!res.success){
				  B.alert("提示",res.msg);
			}else{  
				  nativePage.executeScript("doClick_A("+relydata.fileid+",'"+res.filename+"')");		
			}
		}
		
		//【业务部领导审批】
		function ywxldsp(){
			var ob1 = document.getElementById('10_user_tr');
			var ob2 = document.getElementById('14_user_tr');
			if($('#m_sfzcsx').val()==1){
				if(ob1)	ob1.style.display='none';
				if(ob2)	ob2.style.display='';
				//设置必须输入的步骤id
				getYcbzbh("11");
				//自动带出项目经理
				ajaxGetXmInfo2();
				getNextStepId(flowid,'11');
			}else{
				if(ob1)	ob1.style.display='';
				getYcbzbh("10");
				if(ob2)	ob2.style.display='none';
			}
		}
		

		function ajaxGetXmInfo2() {
			isStart=true;
			isSxian=true;
			var id  = $('#m_xmmc').attr('hidID');
			baseAjax({
				pattern:'http://getXmInfo2',
				data:{'projectid':id},
				isBlock:true,
				success:'successAjaxGetXmInfo2',
				error:''
			});
		}
		
		function successAjaxGetXmInfo2(ajax){
			rs1 = eval('('+ajax.responseText+')');
		}
		
		function getNextStepId(flowid,stepcode){
			baseAjax({
				pattern:'http://getNextStepId',
				data:{'flowid':flowid,
				'stepcode':stepcode},
				isBlock:true,
				success:'successGetNextStepId',
				error:''
			});
		}
		
		function successGetNextStepId(ajax){
			res1 = eval('('+ajax.responseText+')');
			if(res1.success){
				nextstepid1 = res1.stepid;
				if(stepcode=="15"){
					$('#step_' + nextstepid1 + "_user").attr("hidID", rs1.m_xmjlid);
					$('#step_' + nextstepid1 + "_user").val(rs1.m_xmjl);
				}else if(stepcode=="11"){
					$('#step_' + nextstepid1 + "_user").attr("hidID", rs1.m_kffzrid);
					$('#step_' + nextstepid1 + "_user").val(rs1.m_kffzr);
				}else if(stepcode=="09"){
					$('#step_' + nextstepid1 + "_user").attr("hidID", rs1.m_xmjlid);
					$('#step_' + nextstepid1 + "_user").val(rs1.m_xmjl);
				}else if(stepcode=="10"){
					$('#step_' + nextstepid1 + "_user").attr("hidID", userid);
					$('#step_' + nextstepid1 + "_user").val(username);
				}else if(stepcode=="14"){
					$('#step_' + nextstepid1 + "_user").attr("hidID", rs1.m_yydbid);
					$('#step_' + nextstepid1 + "_user").val(rs1.m_yydb);
				}else if(stepcode=="17"){
					$('#step_' + nextstepid1 + "_user").attr("hidID", yydbObj.userid);
					$('#step_' + nextstepid1 + "_user").val(yydbObj.username);
				}else if(stepcode=="22"){
					$('#step_' + nextstepid1 + "_user").attr("hidID", rs1.m_ywdbid);
					$('#step_' + nextstepid1 + "_user").val(rs1.m_ywdb);
				}
			}
			return nextstepid1;
		}
		
		//查询运营代表审批步骤的处理人
		var yydbObj;
		function ajaxGetWfyydb(flowid,wfid,stepcode){
			baseAjax({
				pattern:'http://getWfyydb',
				data:{'flowid':flowid,
				'wfid':wfid,
				'stepcode':stepcode},
				isBlock:true,
				success:'successFunction_5',
				error:''
			});
		}
		
		function successFunction_5(ajax){
			yydbObj = eval('('+ajax.responseText+')');
			if(yydbObj.success){
			}
			return yydbObj;
		}

		function yckf(){
			var ob1 =  document.getElementById("12_user_tr");
			if(ob1){
				ob1.style.display="none";
			}
		}
		
		//带出之前设置过的运维部组长
		function dcywbzz(){
			baseAjax({
				pattern:'http://getysywbzz',
				data:{'flowid':flowexpid,
				'stepcode':stepcode},
				isBlock:true,
				success:'successDcywbzz',
				error:''
			});
		}
		
		function successDcywbzz(ajax){
			var res = eval('('+ajax.responseText+')');
			$('#step_527_user').attr("hidID", res.userid);
			$('#step_527_user').val(res.username);
		}
		
		//带出之前设置过的开发部领导
		function dckfbld(){
			baseAjax({
				pattern:'http://getyskfbld',
				data:{'flowid':flowexpid,
				'stepcode':stepcode},
				isBlock:true,
				success:'successDckfbld',
				error:''
			});
		}
		
		function successDckfbld(ajax){
			var res = eval('('+ajax.responseText+')');
			$('#step_525_user').attr("hidID", res.userid);
			$('#step_525_user').val(res.username);
		}
		
		//开发部领导审批
		function kfbldsp(){
			var ob1 = document.getElementById('16_user_tr');//运维部组长审批
			var ob2 = document.getElementById('18_user_tr');//执行人执行
			var m_xmsslb = document.getElementById('m_xmsslb').value;//0,支持类;1,开发类
			var m_wcshjsx= $("#m_wcshjsx").val();
			if(m_xmsslb=="1"&&m_wcshjsx=="2"){
				if(ob2) ob2.style.display='none';
				getYcbzbh("17");
			}else if(m_xmsslb=="1"&&m_wcshjsx=="1"){
				if(ob1) ob1.style.display='none';
				getYcbzbh("18");
			}else if(m_xmsslb=="0"){
				if(ob1) ob1.style.display='none';
				if(ob2) ob2.style.display='none';
			}
		}
		
		if(stepcode=="14"){
			document.getElementById("m_wcshjsx").onchange = function(){
				var m_wcshjsx=$("#m_wcshjsx").val();
				var m_xmsslb=$("#m_xmsslb").val();
				var ob1 = document.getElementById('16_user_tr');//运维部组长审批
				var ob2 = document.getElementById('18_user_tr');//执行人执行
				if(m_wcshjsx=="1"){//选择是
					if(m_xmsslb=="1"){
						if(ob1) ob1.style.display='none';
						if(ob2) ob2.style.display='';
					}
				}else{
					if(ob1) ob1.style.display='';
					if(ob2) ob2.style.display='none';
				}
			}
		}
		
		if(stepcode=="11"){
			//当【是否部分上线】选择“否”，【是否最终上线】字段联动默认为“是”且不可手动修改
			document.getElementById("m_sfbfsx").onchange = function(){
				if(document.getElementById("m_sfbfsx").value=='1'){
					document.getElementById('m_sfzzsx').value = '0';
					$('#m_sfzzsx').attr("disabled", true);
				}else if(document.getElementById("m_sfbfsx").value=='0'){
					document.getElementById('m_sfzzsx').value = '1';
					$('#m_sfzzsx').attr("disabled", false);
				}
			}
		}
		
//		if(stepcode=="18"){
//			//在【执行人执行】步骤判断输入的执行时间是否和申请上线时间相同，不同则给出提示
//			var obj1 = document.getElementById('m_zxsj');
//			if(obj1){
//				document.getElementById("m_zxsj").onchange = function(){
//					var obj2 = document.getElementById('m_sqsxsj');
//					if(obj2){
//						if(obj1.value != obj2.value){
//							B.alert("提示",'您输入的执行时间和申请上线时间不同！');
//						}
//					}
//				}
//			}
//		}
		
		function successGetyyzzve(ajax){
			var ywzzarraystr = eval('('+ajax.responseText+')');
			ywzzarray = ywzzarraystr.ywzzarray;
		}

