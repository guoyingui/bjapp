    var mescroll;
    document.addEventListener("plusready",function(){
        mescroll = new MeScroll("mescroll", { //第一个参数"mescroll"对应上面布局结构div的id
	        down: {
	            callback: downCallback,
	        },
	        up: {
	        	use : false
	        }
    	});
    },false);
    function downCallback() {
    	var status = 0;
		baseAjax({
			pattern : "http://wokFlowHandle",
			method : "post",
			data : {
				status : status
			},
			isBlock : true,
			success : "successFunction",
			error : "failFunction"
		});   	
    }
    var jsparam = 0;  //计数
    function successFunction (ajax){
		var data = eval("("+ajax.responseText+")");
		mescroll.endSuccess();
		$('.pend_list ul').empty().not($(this));
        var  mylists = data.listData;
        listCode(mylists);
        
        //待评审查找功能
        $('.sech_ipt2').get(0).onkeydown=function(){
	         jsparam++;
	    }
		$('.sech_icn').get(0).onclick=function () {
	        $(".pend_list ul").empty().not($(this));
	         listCode(mylists);
	    };
	    $('.sech_ipt2').get(0).onkeyup=function(){
	         $('.sech_icn').get(0).onclick();
	         return;
	    }
	    
	}
	function failFunction (ajax){ 
        mescroll.endErr();
	}
function listCode(data) {
	var jsparamTemp = jsparam;
	var searchvalue = $('.sech_ipt2').val();
	for (var i = 0; i < data.length; i++) {
		if(jsparam>jsparamTemp){
             return;
        }
		var element = data[i];
		if(element.reviewnamepy == undefined){
			$('#flowLabel').val(element.reviewname);
			element.reviewnamepy = $('#flowLabel').toPinyin().toLowerCase();
		};
		if (searchvalue != "" && element.reviewname.indexOf(searchvalue) == -1&&element.reviewnamepy.indexOf(searchvalue.toLowerCase()) != 0) {
             continue;
        }
		var stepid = element.stepid;
		var flowid = element.flowid;
		var objectid = element.objectid;
		var objecttype = element.objecttype;
		var reviewperid = element.reviewperid;
		var showChangeUserBtn = element.showChangeUserBtn;
		$('.pend_list ul').append('<li class="list"><div class="pend_mide" style="transition-duration: 0.3s; transform: translate3d(0px, 0px, 0px);" onclick=" parallel(' + stepid + ',' + flowid + ',' + objectid + ',' + objecttype + ',' + reviewperid + ','+showChangeUserBtn+')">' + 
		'<figure class="pd_icnl"></figure>' + 
		'<hgroup><h4 class="whohas">' + element.reviewname + '</h4>' + 
		'<p class="hgroup">评审类型:'+ element.stepname +'</p>' +
		'<p><span class="element">主持人:' + element.annotateusername + '</span><time>' + element.startdate + '</time></p></hgroup></div>' + 
		'<div class="subListTitle right"><span class="subRight" onclick="saveEnsure(\'6\',this)"><img src="assets/app/img/icon_8.png"></span><span class="subRight" onclick="saveEnsure(\'5\',this)" style="border-left: 1px solid #fff;border-right: 1px solid #fff;"><img src="assets/app/img/icon_34.png"></span><span class="subRight" onclick="saveEnsure(\'4\',this)"><img src="assets/app/img/icon_30.png"></span></div></li>')
	};
	if($('.pend_list ul li').length==0){
	    $('.pend_list ul').append('<li class="pend_shuju">没有搜索到数据</li>');
	};
	
	var list = document.getElementsByClassName("list");
	for (var i = 0; i < list.length; i++) {
		list[i].addEventListener("touchstart", touch, false);
		list[i].addEventListener("touchmove", touch, false);
		list[i].addEventListener("touchend", touch, false);
	}
	var pendmide = document.getElementsByClassName("pend_mide");
	for (var i = 0; i < pendmide.length; i++) {
		pendmide[i].addEventListener("touchstart", function(event) {
			var thises = window.getComputedStyle(event.currentTarget, "").transform;
			thises = Math.abs(Number(thises.substring(7, thises.length - 1).split(",")[4]));
			if (thises == 0) {
				var pendmide = document.getElementsByClassName("pend_mide");
				for (var i = 0; i < pendmide.length; i++) {
					pendmide[i].style.transform = 'translate3d(0px,0px, 0px)';
				}
			}
			event.currentTarget.style.backgroundColor = "#D9D9D9";
		}, false);

		pendmide[i].addEventListener("touchmove", function(event) {
			event.currentTarget.style.backgroundColor = "white";
		}, false);

		pendmide[i].addEventListener("touchend", function(event) {
			event.currentTarget.style.backgroundColor = "white";
		}, false);
	}
}
var clickListFlag = true;
var userData ;
var elementChecked;
var dataObj;
function parallel( stepid, flowid, objectid, objecttype, reviewperid, showChangeUserBtn) {
    userData = {
        flowid: flowid,
        stepid: stepid,
        objectid: objectid,
        objecttype: objecttype,
        reviewperid: reviewperid,
        showChangeUserBtn:showChangeUserBtn
    };
    // 页面之间传值
    var user = JSON.stringify(userData);
    if(clickListFlag){
        window.location.href = 'BulkReviewInit.html?data=' + user;
    }
    clickListFlag = true;
}

function setIframeInfo(element){
    clickListFlag = false;
    element.onclick();
}

function saveEnsure(annotfalg,element) {
    userData.annotfalg = annotfalg;
    elementChecked = element;
    baseAjax({
            pattern:"http://getAnnotInfoForTouchMove",
            method:"post",
            data:userData,
            isBlock:true,
            success:"successFunction_1",
            error:""
    });
}

function successFunction_1(ajax){
    if(ajax.responseText.indexOf("系统session超时") != -1){
         B.alert("提示", "系统session超时,请重新登录", function() {
              nativePage.executeScript("back()");
         });
         return;
    }
    var data = eval("("+ajax.responseText+")");
    if(data.success){
        dataObj = data.objData;
        if(userData.annotfalg == "4"){
        	B.confirm("提示","确定提交该评审?",function(){
                dataObj.annotfalg = userData.annotfalg;
                if($.trim(dataObj.annotateresult)==""){
                    dataObj.annotateresult = "同意";
                }
                var savetype = '2';
                if(!userData.showChangeUserBtn){
                    savetype = '5';
                }
                save(savetype);
            },function(){})
        }else if(userData.annotfalg == "5"){
        	var text = "";
            B.confirm('有条件通过评审意见', '<textarea id="opinion_note" style="width:94.8%;border:none;-webkit-user-select: auto !important;-webkit-touch-callout: none !important;" cols="10" rows="30" placeholder="请填写意见"></textarea>',function(){
                var note = $("#opinion_note").val();
                if($.trim(note)==""){
                    return false;
                }
                dataObj.annotfalg = userData.annotfalg;
                dataObj.annotateresult = note;
                var savetype = '2';
                if(!userData.showChangeUserBtn){
                    savetype = '5';
                }
                save(savetype);
            },function(){});
        }else{
        	var text = "";
            B.confirm('不通过评审意见', '<textarea id="opinion_note" style="width:94.8%;border:none;-webkit-user-select: auto !important;-webkit-touch-callout: none !important;" cols="10" rows="30" placeholder="请填写意见"></textarea>',function(){
                var note = $("#opinion_note").val();
                if($.trim(note)==""){
                    return false;
                }
                dataObj.annotfalg = userData.annotfalg;
                dataObj.annotateresult = note;
                var savetype = '2';
                if(!userData.showChangeUserBtn){
                    savetype = '5';
                }
                save(savetype);
            },function(){});
        }
    }else{
        B.alert("提示",data.msg);
    }  
}

function save(savetype){
        var com = dataObj.commenting;
        if(savetype=='2'){
            baseAjax({
                pattern : "http://saveCommenting",
                method : "post",
                data : {
                    savetype: savetype,
                    com: com,
                    reviewPerid : dataObj.reviewPerid
                },
                isBlock : true,
                success : "successFunction_2",
                error : "",
                relydata:{savetype:savetype}
            });
        }else{
            submitData(savetype);
        }
}

function successFunction_2(ajax){
    if(ajax.responseText.indexOf("系统session超时") != -1){
            B.alert("提示", "系统session超时,请重新登录", function() {
                nativePage.executeScript("back()");
            });
            return;
     }
     var relydata = JSON.parse(ajax.getStringData("relydata"));
     submitData(relydata.savetype); 
}

function submitData(savetype){
    baseAjax({
                pattern : "http://saveAnnotateInfo",
                method : "post",
                data : dataObj,
                isBlock : true,
                success : "successFunction_3",
                error : ""
    });
}

function successFunction_3(ajax){
    if(ajax.responseText.indexOf("系统session超时") != -1){
            B.alert("提示", "系统session超时,请重新登录", function() {
                nativePage.executeScript("back()");
            });
            return;
     }
     var data = eval("(" + ajax.responseText + ")");
        if(!data.success){
            B.alert('提示',data.msg,function(){
                if(data.msg.indexOf("系统session超时")!=-1){
                    nativePage.executeScript("back()");
                }
            });
        }else{
            B.alert('提示','操作成功',function(){
                $(elementChecked).parent().parent().remove();
                mescroll.triggerDownScroll();
            });
        }
}
