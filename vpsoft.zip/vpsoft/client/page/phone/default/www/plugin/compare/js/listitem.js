/*
 *	ExMobi4.x+ JS
 *	Version	: 1.0.0
 *	Author	: Administrator
 *	Email	:
 *	Weibo	:
 *	Copyright 2016 (c)
 */

//左滑右滑
$("body").on("touchstart", function(e) {
	e.preventDefault();
	startX = e.originalEvent.changedTouches[0].pageX,
	startY = e.originalEvent.changedTouches[0].pageY;
});
$("body").on("touchmove", function(e) {
	e.preventDefault();
	moveEndX = e.originalEvent.changedTouches[0].pageX,
	moveEndY = e.originalEvent.changedTouches[0].pageY,
	X = moveEndX - startX,
	Y = moveEndY - startY;
	//从左向右滑
	if (Math.abs(X) > Math.abs(Y) && X < -35) {
		tabs[1].onclick();
	} else if (Math.abs(X) > Math.abs(Y) && X > 35) {//从右向左滑
		tabs[0].onclick();
	}
});

 // 列表点击收缩
$(".group").click(function() {
	 $(this).next().slideToggle();
	 $(this).find('i').toggleClass('icon-arrowdown');
	 $(this).find('i').toggleClass('icon-arrowright');
});
$("#ListElementHead").children(":first").next().children(":first").click();

$('#annot_psjl').click(function(){
	$(this).hide();
})

$('#annot_fj').click(function() {
	$(this).hide();
	return false;
});
$('.annot_big').click(function() {
	return false;
});
$('.annot_qx').click(function() {
	$('#annot_fj').hide();
});
$('.annot_ck').click(function() {
	$('#annot_fj').css('display', 'block')
	//$('.annot_ck').animate({
		//right : '0'
	//}, 300)
});

$(".form-row ul li span").click(function() {
	$(this).next().slideToggle();
	$(this).find('i').toggleClass('icon-arrowright');
});

$('#middle').click(function () {
    $('.list_ggclr').css('display', 'block')
    baseAjax({
        pattern:'http://getDepUser',
        data:{},
        isBlock:true,
        success:'successFunction2',
        error:'failFunction2'
    });
})
var jsparam = 0;  //计数
function successFunction2(ajax){
    var data = eval("("+ajax.responseText+")");
    $("#list_ryxs_table").empty().not($(this));
    $('.list_ss').val("");
	var users = data.userlist;
    for (var i = 0; i < users.length; i++) {
        var user = users[i];
        if(user.userjp==undefined){
             $("#pinyin").val(user.username);
             user.userjp=$("#pinyin").toPinyin().toLowerCase();
        }
        if(user.username.indexOf('administrator') > -1 || user.username.indexOf('user') > -1 || user.username.indexOf('安全可控') > -1){
             continue;
       	}
        var data = '<tr><td><input name="departmentname" type="checkbox" value="' + user.userid + '"/>' +
        	'</td><td>' + user.username + '</td><td>' + user.departmentname + '</td></tr>';
        $('#list_ryxs_table').append(data);
    };
    var checkboxValue = new Array();
    checkboxValue.push(users);
    $('input[name="departmentname"]').click(function () {
    	var val = $(this).attr("value");
    	$('input[name="departmentname"]:checked').each(function(){
    		if(val != $(this).attr("value")){
    			$(this).attr('checked',false)
    		}else{
    			$(this).attr('checked',true)
    		}
    	})
    })
    
    $('.list_ss').get(0).onkeydown=function(){
	         jsparam++;
	    }
		$('.list_djss').get(0).onclick=function () {
	        $("#list_ryxs_table").empty().not($(this));
	         usersData(checkboxValue);
	    };
	    $('.list_ss').get(0).onkeyup=function(){
	         $('.list_djss').get(0).onclick();
	         return;
	    }
}	  	 
function failFunction2(ajax){
	B.alert('提示','请求失败');
}

function usersData(checkboxValue) {
	var jsparamTemp = jsparam;
    for (var k = 0; k < checkboxValue[0].length; k++) {
    	if(jsparam>jsparamTemp){
            return;
        }
        var SearchBox_adv = checkboxValue[0][k];
        var searchText = $('.list_ss').val();
        if (searchText != "" && SearchBox_adv.username.indexOf(searchText) == -1&&SearchBox_adv.userjp.indexOf(searchText.toLowerCase()) != 0) {
            continue;
        }
        if(SearchBox_adv.username.indexOf('administrator') > -1 || SearchBox_adv.username.indexOf('user') > -1 || SearchBox_adv.username.indexOf('安全可控') > -1){
             continue;
       	}
        var sech_icn2 = '<tr><td><input name="departmentname" type="checkbox" value="' + SearchBox_adv.userid + '"/>' +
        '</td><td>' + SearchBox_adv.username + '</td><td>' + SearchBox_adv.departmentname + '</td></tr>'
        $('#list_ryxs_table').append(sech_icn2) 
    }
    $('input[name="departmentname"]').click(function () {
    	var val = $(this).attr("value");
    	$('input[name="departmentname"]:checked').each(function(){
    		if(val != $(this).attr("value")){
    			$(this).attr('checked',false)
    		}else{
    			$(this).attr('checked',true)
    		}
    	})
    })
}

$('.list_qx').click(function(){
	$('.list_ggclr').css('display', 'none');
})

 $('.list_qdtj .list_qd').click(function() {
	var val = $("input[name=departmentname]:checked").val();
	if(val==undefined){
		B.alert('提示','请选择处理人');
		return;
	}
	var type = 1;
	baseAjax({
		pattern : "http://setpreuserdata",
		method : "post",
		data:"type="+type+"&stepid="+stepid+"&flowid="+flowid+"&reviewPerid="+reviewPerid+"&userid="+val,
		isBlock : true,
		success : "successFunction3",
		error : "failFunction3"
	});   	
})
function successFunction3(ajax){
	B.alert('提示','操作成功',function(){
		location.href = 'reviewboard.html';
	});
}
function failFunction3(ajax){
	B.alert('提示','提交失败');
}



