/** * Time:2017/1018 * Author:GuanQun *  */
function touch(event) {
	//获取触发滑动事件的Dom元素
	var listDome = event.currentTarget.childNodes[0];
	//侧滑菜单

	var subCountWidth = event.currentTarget.childNodes[1].children;
	switch (event.type) {

		case "touchstart":
			//计算侧滑菜单宽度
			subWidth = 0;
			for (var i = 0; i < subCountWidth.length; i++) {
				subWidth = subWidth + subCountWidth[i].clientWidth;
			}

			listDome.style.transitionDuration = "0.3s";
			marginRight = window.getComputedStyle(listDome, "").transform;
			marginRight = Math.abs(Number(marginRight.substring(7, marginRight.length - 1).split(",")[4]));
			//触摸点x轴距离
			$startX = event.touches[0].clientX;
			$startY = event.touches[0].clientY;
			//触摸点至移动之后得到的x轴距离
			touchesX = 0;
			touchesY = 0;
			break;
		case "touchmove":

			listDome.style.transitionDuration = "0s";
			$moveX = event.touches[0].clientX;
			$moveY = event.touches[0].clientY;
			touchesX = $startX - $moveX;
			touchesY = $startY - $moveY;
			// console.log("移动X距离----" + touchesX);
			//滑块距离右边实际距离 >= 0时
			if (Math.abs(touchesX) > Math.abs(touchesY)) {
				if (marginRight >= 0) {
					if (marginRight + touchesX < 0) {
						listDome.style.transform = 'translate3d(0px,0px, 0px)';
					} else if (marginRight + touchesX <= 500) {
						listDome.style.transform = 'translate3d(-' + (marginRight + touchesX) + 'px,0px, 0px)';
					} else {
						listDome.style.transform = 'translate3d(-' + subWidth + 'px,0px, 0px)';
					}
				} else if (marginRight < 0) {
					listDome.style.transform = 'translate3d(0px,0px, 0px)';
				}
			}
			break;
		case "touchend":
			listDome.style.transitionDuration = "0.3s";
			marginRight = window.getComputedStyle(listDome, "").transform;
			marginRight = Math.abs(Number(marginRight.substring(7, marginRight.length - 1).split(",")[4]));
			if (Math.abs(touchesX) > Math.abs(touchesY)) {
				if (marginRight <= 58 || touchesX <= -58) {
					listDome.style.transform = 'translate3d(0px,0px, 0px)';
				} else {
					listDome.style.transform = 'translate3d(-' + subWidth + 'px,0px, 0px)';
					try{
						setIframeInfo(listDome);
					}catch(e){console.log(e)}
				}
			}
			break;
	}
}