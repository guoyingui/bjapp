/*
*	ExMobi4.x+ JS
*	Version	: 1.0.0
*	Author	: luoyi
*	Email	: 
*	Weibo	: 
*	Copyright 2016 (c) 
*/

function baseUrl(){
	var settinginfo = ClientUtil.getSetting();
	var url = "http://"+settinginfo.ip+":"+settinginfo.port+"/process/service/"+ClientUtil.getAppId();
	return url;
}
/** 
 * param 将要转为URL参数字符串的对象 
 * key URL参数字符串的前缀 
 * encode true/false 是否进行URL编码,默认为true 
 * return URL参数字符串 
 */  
var urlEncode = function (param, key, encode) {  
  if(param==null) return '';  
  var paramStr = '';  
  var t = typeof (param);  
  if (t == 'string' || t == 'number' || t == 'boolean') {  
    paramStr += '&' + key + '=' + ((encode==null||encode) ? encodeURIComponent(param) : param);  
  } else {  
    for (var i in param) {  
      var k = key == null ? i : key + (param instanceof Array ? '[' + i + ']' : '[' + i + ']');  
      paramStr += urlEncode(param[i], k, encode);  
    }  
  }  
  return paramStr;  
}; 
function baseAjax(obj){
	var ajaxData = {};   
	ajaxData.url = obj.pattern;       
    ajaxData.method = "post"; 
    if(typeof obj.data =='object'){
    	var params = urlEncode(obj.data,null,false); //$.param(obj.data);
    	//console.log(params);
    	ajaxData.data = params;
    }else{
    	ajaxData.data = obj.data;
    }
    ajaxData.isBlock = obj.isBlock;   		
    ajaxData.successFunction = obj.success;//必需
    ajaxData.failFunction = obj.error;//可选
	//设置请求编码格式
	//ajaxData.reqCharset = "UTF-8";
	//设置回应编码格式
	//ajaxData.rspCharset = "UTF-8";
	//设置连接超时时间 10秒
	ajaxData.connectTimeout = 10;
	//设置读取超时时间 90秒
	ajaxData.timeout = 90;
	var ajax = new Ajax(ajaxData);
	//传递依赖的外部参数，为json格式，以供回调函数中使用
	if(obj.relydata){
		ajax.setStringData("relydata",JSON.stringify(obj.relydata));
	}
	ajax.send();
}

//返回按键触发
document.addEventListener("backmonitor",function(){
	back();
	return false;
},false);

