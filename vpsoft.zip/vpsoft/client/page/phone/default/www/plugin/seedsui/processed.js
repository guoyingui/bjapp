// mescroll 下拉刷新
var mescroll;
document.addEventListener("plusready", function() {
	mescroll = new MeScroll("mescroll", {//第一个参数"mescroll"对应上面布局结构div的id
		//如果您的下拉刷新是重置列表数据,那么down完全可以不用配置,具体用法参考第一个基础案例
		//解析: down.callback默认调用mescroll.resetUpScroll(),而resetUpScroll会将page.num=1,再触发up.callback
		down : {
			callback : downCallback //下拉刷新的回调,别写成downCallback(),多了括号就自动执行方法了
		},
		up : {
			use: false
			 //callback: upCallback //上拉加载的回调
		}
	});
}, false);
// 下拉刷新

function downCallback() {
	baseAjax({
		pattern : "http://yclsearch",
		method : "post",
		data : {},
		isBlock : true,
		success : "successFunction",
		error : "failFunction"
	}); 
}
function upCallback(){
	mescroll.endSuccess();
}

var jsparam = 0;
//var mylist = new Array();
function successFunction(ajax) {
	var data = eval("(" + ajax.responseText + ")");	
	mescroll.endSuccess();
	$('.pend_list ul').empty().not($(this));
	var mylist = data.datalist;
	search(mylist);
	
	//  搜索功能
	$('.sech_ipt').get(0).onkeydown=function(){
         jsparam++;
    }
	$('.sech_icn').get(0).onclick=function () {
         $('.pend_list ul').empty().not($(this));
         search(mylist);
    };
    $('.sech_ipt').get(0).onkeyup=function(){
         $('.sech_icn').get(0).onclick();
         return;
    }
}

function failFunction(ajax) {
	//联网失败的回调,隐藏下拉刷新和上拉加载的状态
	mescroll.endErr();
}

function search(mylist) {
	var jsparamTemp = jsparam;
	var searchvalues = $('.sech_ipt').val();
	for(var n = 0; n < mylist.length; n++){
		if(jsparam>jsparamTemp){
            return;
       	};
		var my_listdata = mylist[n];
		if(my_listdata.objectnamepy==undefined){
	             $("#flowLabel").val(my_listdata.objectname);
	             my_listdata.objectnamepy=$("#flowLabel").toPinyin().toLowerCase();
	             $("#flowLabel").val(my_listdata.flowname);
	             my_listdata.flownamepy=$("#flowLabel").toPinyin().toLowerCase();
        }
		var flowid = my_listdata.flowid;
		var flowInsId = my_listdata.flowInsId;
		var objectid = my_listdata.objectid;
		var objecttype = my_listdata.objecttype;
		
		if (searchvalues != "" && my_listdata.flowname.indexOf(searchvalues) == -1&& my_listdata.objectname.indexOf(searchvalues) == -1 
		&& my_listdata.objectnamepy.indexOf(searchvalues.toLowerCase()) != 0 &&my_listdata.flownamepy.indexOf(searchvalues.toLowerCase()) != 0) {
            continue;
        }
        var paraller = '<a href="HaveDeal.html" class="popup_parallel" onclick="parallel(' + flowid + ',' + flowInsId + ',' + objectid + ',' + objecttype + ')"><li><div class="pend_mide">' + 
        '<figure class="pd_icnl"></figure>' + 
        '<hgroup><h4>' + my_listdata.flowname + '</h4>' + 
        '<p class="hgroup">' + my_listdata.objectname + '</p>' + 
        '<p><span class="element">' + my_listdata.stepname + '</span><time>' + my_listdata.startdate + '</time></p></hgroup>' + 
        '</li></a>';
        $('.pend_list ul').append(paraller)			
	}
	if($(".popup_parallel").length == 0){
		 $('.pend_list ul').append(
	     		'<li class="pend_shuju">没有搜索到数据</li>'
	    )
	}
}

// 点击列表执行的方法带参数
function parallel(flowid, flowInsId, objectid, objecttype) {
	var userData = {
		flowid : flowid,
		flowInsId : flowInsId,
		objectid : objectid,
		objecttype : objecttype
	};
	// 页面之间传值
	var user = JSON.stringify(userData)
	$('.popup_parallel').attr("href", "HaveDeal.html?data=" + user)
}


$(document).ready(function() {
	$(".select-clear").hide();
	$(".select-clear").click(function() {
		$(".select-result dl .selected").remove();
		$(".select-clear").remove();
	})
	$("a[name='canChecked']").click(function() {
        $(this).toggleClass("require");
	})
	$(".select_root a").click(function() {
		$(this).addClass('contarier').siblings().removeClass('contarier');
	});
});

// 弹出框重置功能
$('.determine').click(function() {
	$('.select_root a').removeClass('contarier');
	$('#select1 dd a').removeClass('require')
})
// 弹出框里确定按钮执行的方法
$('.replacement').click(function() {
	var filterId = $('.contarier').attr('name');
	var objecttypes = "";
	$('.require').each(function(){
	    if(objecttypes.length!=0){
	        objecttypes += ",";
	    }
	    objecttypes += $(this).attr("hidID");
	});
	//  隐藏弹出框
	$('#right_overlay_aside').removeClass('active');
	$('#section_container_mask').css({
		'display' : 'none'
	});
	$('.sech_ipt').val('');
	baseAjax({
		pattern : "http://yclsearch",
		method : "post",
		data : {
			filterId : filterId,
			objecttypes:objecttypes
		},
		isBlock : true,
		success : "successFunction3",
		error : "failFunction3"
	}); 
});
function successFunction3(ajax) {
	var data = eval("(" + ajax.responseText + ")");
	$('.pend_list ul').empty().not($(this));
	var list = data.datalist;
	$('.sech_icn').get(0).onclick=function () {
         $('.pend_list ul').empty().not($(this));
         search(list);
    };
	if (data.datalist.length == 0) {
		$('.pend_list ul').append('<li class="pend_shuju">没有搜索到数据</li>');
		return false;
	}
	for (var index = 0; index < list.length; index++) {
		var element = list[index];
		if(element.objectnamepy==undefined){
                 $("#flowLabel").val(element.objectname);
                 element.objectnamepy=$("#flowLabel").toPinyin().toLowerCase();
                 $("#flowLabel").val(element.flowname);
                 element.flownamepy=$("#flowLabel").toPinyin().toLowerCase();
        }
		var flowid = element.flowid;
		var flowInsId = element.flowInsId;
		var objectid = element.objectid;
		var objecttype = element.objecttype;
		$('.pend_list ul').append('<a href="HaveDeal.html" class="popup_parallel" onclick="parallel(' + flowid + ',' + flowInsId + ',' + objectid + ',' + objecttype + ')"><li><div class="pend_mide">' + '<figure class="pd_icnl"></figure>' + '<hgroup><h4>' + element.flowname + '</h4>' + '<p class="hgroup">' + element.objectname + '</p>' + '<p><span class="element">' + element.stepname + '</span><time>' + element.startdate + '</time></p></hgroup>' + '</li></a>')
	}
}

function failFunction3(ajax) {

};