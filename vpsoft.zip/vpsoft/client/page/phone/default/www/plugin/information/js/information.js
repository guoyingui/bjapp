//  导航条左右切换
var tabs = document.getElementsByClassName('tab-head')[0].getElementsByTagName('h5'),
    contents = document.getElementsByClassName('tab-content')[0].getElementsByTagName('section');
(function changeTab(tab) {
    for (var i = 0, len = tabs.length; i < len; i++) {
        tabs[i].onclick = showTab;
    }
})();

function showTab() {
    for (var i = 0, len = tabs.length; i < len; i++) {
        if (tabs[i] === this) {
            tabs[i].className = 'selected';
            contents[i].className = 'show';
        } else {
            tabs[i].className = '';
            contents[i].className = '';
        }
    }
}

// 从url后面取出数据并进行解析成对象
function getUrlParam(name) {
    //构造一个含有目标参数的正则表达式对象
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    //匹配目标参数 
    var r = window.location.search.substr(1).match(reg);
    //返回参数值
    if (r != null) return unescape(r[2]);
    return null;
}
var urlData = getUrlParam('data');
var user = JSON.parse(urlData);
//console.log(user);

var flowid = user.flowid;
var flowInsId = user.flowInsId;
var stepid = user.stepid;
var stepInsId = user.stepInsId;
var stepcode = user.stepcode;
var objecttype = user.objecttype;

//  更改处理人弹出框：显示/隐藏
$('.btn_alert').click(function () {
    $('#pop_custom').show();
    baseAjax({
        pattern:'http://getDepUser',
        data:{'stepcode':stepcode},
        isBlock:true,
        success:'successFunctionA',
        error:'failFunctionA'
    });
})

function successFunctionA(ajax){
    var data = eval("("+ajax.responseText+")");
    $('#pop_custom3_table').empty().not($(this));
	var users = data.userlist;
    for (var i = 0; i < users.length; i++) {
        var user = users[i];
        if(user.userjp==undefined){
             $("#pinyin").val(user.username);
             user.userjp=$("#pinyin").toPinyin().toLowerCase();
        }
        if(user.username.indexOf('administrator') > -1 || user.username.indexOf('user') > -1 || user.username.indexOf('安全可控') > -1){
        	continue;
        }
        var data = '<tr><td><input name="departmentname" type="checkbox" value="' + user.userid + '"/>' +
        	'</td><td>' + user.username + '</td><td>' + user.departmentname + '</td></tr>';
        $('#pop_custom3_table').append(data);
    };
    var checkboxValue = new Array();
    checkboxValue.push(users);
    $('input[name="departmentname"]').click(function () {
    	var val = $(this).attr("value");
    	$('input[name="departmentname"]:checked').each(function(){
    		if(val != $(this).attr("value")){
    			$(this).attr('checked',false)
    		}else{
    			$(this).attr('checked',true)
    		}
    	})
    })
    
    $('.popup-point').get(0).onclick=function () {
         $('#pop_custom3_table').empty().not($(this));
         SearchBox(checkboxValue);
    };
    
    $('#popup_input').get(0).onkeydown=function(){
         jsparam++;
    }
    $('#popup_input').get(0).onkeyup=function(){
         $('.popup-point').get(0).onclick();
         return;
    }
}	  	 
function failFunctionA(ajax){
	B.alert('提示','请求失败');
}



function SearchBox(checkboxValue) {
	//alert(checkboxValue);
	var jsparamTemp = jsparam;
    for (var k = 0; k < checkboxValue[0].length; k++) {
    	if(jsparam>jsparamTemp){
            return;
        }
        var SearchBox_adv = checkboxValue[0][k];
        var searchText = $('#popup_input').val();
        if (searchText != "" && SearchBox_adv.username.indexOf(searchText) == -1&&SearchBox_adv.userjp.indexOf(searchText.toLowerCase()) != 0) {
            continue;
        }
        if(SearchBox_adv.username.indexOf('administrator') > -1 || SearchBox_adv.username.indexOf('user') > -1 || SearchBox_adv.username.indexOf('安全可控') > -1){
        	continue;
        }
        var sech_icn2 = '<tr><td><input name="departmentname" type="checkbox" value="' + SearchBox_adv.userid + '"/>' +
        '</td><td>' + SearchBox_adv.username + '</td><td>' + SearchBox_adv.departmentname + '</td></tr>'
        $('#pop_custom3_table').append(sech_icn2) 
    }
    $('input[name="departmentname"]').click(function () {
    	var val = $(this).attr("value");
    	$('input[name="departmentname"]:checked').each(function(){
    		if(val != $(this).attr("value")){
    			$(this).attr('checked',false)
    		}else{
    			$(this).attr('checked',true)
    		}
    	})
    })
}

$('.btn_que').click(function () {
    var val = $("input[name=departmentname]:checked").val();
    if(val==undefined){
    	B.alert('提示','请选择处理人');
    	return;
    }
    baseAjax({
        pattern:'http://changeUser',
        data:"flowid="+flowid+"&flowInsID="+flowInsId+"&stepid="+stepid+"&stepInsID="+stepInsId+"&users="+val,
        isBlock:true,
        success:'successFunctionB',
        error:'failFunctionB'
    });
})

function successFunctionB(ajax){
	//var data = eval("("+ajax.responseText+")");
	B.alert('提示','操作成功',function(){
		location.href = 'pending.html';
	});
}	  	 
function failFunctionB(ajax){
	B.alert('提示','请求失败');
}
// 点击弹出框显示
$('.Inlist').click(function () {
    $('#pop_custom1').css('display', 'block')
})
// 点击弹出框隐藏
$('.btn_confirm').click(function () {
    $('.pop_custom').css('display', 'none');
});
$('#tab_xiao').click(function(){
    $('#enclosure').css('display','none')
    $('.tab_pander').animate({right:'-500'},300)
});
$(function(){
    $('#enclosure').click(function(){
        $(this).hide();
        return false;
    });
    $('.tab_pander').click(function(){
        return false;
    });
})
$('.input_labname').click(function(){
    $('#enclosure').css('display','block')
    $('.tab_pander').animate({right:'0'},300)
});
